/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2012                    */
/* Created on:     5/31/2023 5:36:07 PM                         */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CAMA') and o.name = 'FK_CAMA_ASIGNAHAB_HABITACI')
alter table CAMA
   drop constraint FK_CAMA_ASIGNAHAB_HABITACI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CITA') and o.name = 'FK_CITA_ABREHISTO_HISTORIA')
alter table CITA
   drop constraint FK_CITA_ABREHISTO_HISTORIA
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CITA') and o.name = 'FK_CITA_ASIGNACON_CONSULTO')
alter table CITA
   drop constraint FK_CITA_ASIGNACON_CONSULTO
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CITA') and o.name = 'FK_CITA_PACIENTEC_PACIENTE')
alter table CITA
   drop constraint FK_CITA_PACIENTEC_PACIENTE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MEDICOS') and o.name = 'FK_MEDICOS_ATIENDECO_CONSULTO')
alter table MEDICOS
   drop constraint FK_MEDICOS_ATIENDECO_CONSULTO
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MEDICOS') and o.name = 'FK_MEDICOS_MODIFICAH_HISTORIA')
alter table MEDICOS
   drop constraint FK_MEDICOS_MODIFICAH_HISTORIA
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PACIENTE') and o.name = 'FK_PACIENTE_ASIGNACAM_CAMA')
alter table PACIENTE
   drop constraint FK_PACIENTE_ASIGNACAM_CAMA
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PACIENTE') and o.name = 'FK_PACIENTE_TIENEHIST_HISTORIA')
alter table PACIENTE
   drop constraint FK_PACIENTE_TIENEHIST_HISTORIA
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CAMA')
            and   name  = 'ASIGNAHABITACION_FK'
            and   indid > 0
            and   indid < 255)
   drop index CAMA.ASIGNAHABITACION_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CAMA')
            and   type = 'U')
   drop table CAMA
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CITA')
            and   name  = 'PACIENTECITA_FK'
            and   indid > 0
            and   indid < 255)
   drop index CITA.PACIENTECITA_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CITA')
            and   name  = 'ABREHISTORIA_FK'
            and   indid > 0
            and   indid < 255)
   drop index CITA.ABREHISTORIA_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CITA')
            and   name  = 'ASIGNACONSULTORIO_FK'
            and   indid > 0
            and   indid < 255)
   drop index CITA.ASIGNACONSULTORIO_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CITA')
            and   type = 'U')
   drop table CITA
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONSULTORIO')
            and   type = 'U')
   drop table CONSULTORIO
go

if exists (select 1
            from  sysobjects
           where  id = object_id('HABITACION')
            and   type = 'U')
   drop table HABITACION
go

if exists (select 1
            from  sysobjects
           where  id = object_id('HISTORIACLINICA')
            and   type = 'U')
   drop table HISTORIACLINICA
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MEDICOS')
            and   name  = 'MODIFICAHISTORIA_FK'
            and   indid > 0
            and   indid < 255)
   drop index MEDICOS.MODIFICAHISTORIA_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MEDICOS')
            and   name  = 'ATIENDECONSULTORIO_FK'
            and   indid > 0
            and   indid < 255)
   drop index MEDICOS.ATIENDECONSULTORIO_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('MEDICOS')
            and   type = 'U')
   drop table MEDICOS
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PACIENTE')
            and   name  = 'TIENEHISTORIA_FK'
            and   indid > 0
            and   indid < 255)
   drop index PACIENTE.TIENEHISTORIA_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PACIENTE')
            and   name  = 'ASIGNACAMA_FK'
            and   indid > 0
            and   indid < 255)
   drop index PACIENTE.ASIGNACAMA_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('PACIENTE')
            and   type = 'U')
   drop table PACIENTE
go

/*==============================================================*/
/* Table: CAMA                                                  */
/*==============================================================*/
create table CAMA (
   IDCAMA               varchar(10)          not null,
   IDHABITACION         varchar(10)          not null,
   ID2_PACIENTE         varchar(2)           not null,
   constraint PK_CAMA primary key nonclustered (IDCAMA)
)
go

/*==============================================================*/
/* Index: ASIGNAHABITACION_FK                                   */
/*==============================================================*/
create index ASIGNAHABITACION_FK on CAMA (
IDHABITACION ASC
)
go

/*==============================================================*/
/* Table: CITA                                                  */
/*==============================================================*/
create table CITA (
   IDCITA               varchar(15)          not null,
   IDCONSULTORIO        varchar(3)           not null,
   IDHISTORIA           varchar(10)          not null,
   CEDULAPAC            varchar(10)          not null,
   FECHACITA            datetime             not null,
   HORACITA             datetime             not null,
   ESPECIALIDADCITA     varchar(15)          not null,
   constraint PK_CITA primary key nonclustered (IDCITA)
)
go

/*==============================================================*/
/* Index: ASIGNACONSULTORIO_FK                                  */
/*==============================================================*/
create index ASIGNACONSULTORIO_FK on CITA (
IDCONSULTORIO ASC
)
go

/*==============================================================*/
/* Index: ABREHISTORIA_FK                                       */
/*==============================================================*/
create index ABREHISTORIA_FK on CITA (
IDHISTORIA ASC
)
go

/*==============================================================*/
/* Index: PACIENTECITA_FK                                       */
/*==============================================================*/
create index PACIENTECITA_FK on CITA (
CEDULAPAC ASC
)
go

/*==============================================================*/
/* Table: CONSULTORIO                                           */
/*==============================================================*/
create table CONSULTORIO (
   IDCONSULTORIO        varchar(3)           not null,
   ESTADOCONSULTORIO    varchar(2)           not null,
   constraint PK_CONSULTORIO primary key nonclustered (IDCONSULTORIO)
)
go

/*==============================================================*/
/* Table: HABITACION                                            */
/*==============================================================*/
create table HABITACION (
   IDHABITACION         varchar(10)          not null,
   ESTADOHABITACION     varchar(1)           not null,
   constraint PK_HABITACION primary key nonclustered (IDHABITACION)
)
go

/*==============================================================*/
/* Table: HISTORIACLINICA                                       */
/*==============================================================*/
create table HISTORIACLINICA (
   IDHISTORIA           varchar(10)          not null,
   FECHAHISTORIA        datetime             not null,
   DATOSHISTORIA        varchar(1000)        not null,
   constraint PK_HISTORIACLINICA primary key nonclustered (IDHISTORIA)
)
go

/*==============================================================*/
/* Table: MEDICOS                                               */
/*==============================================================*/
create table MEDICOS (
   CEDULAMED            varchar(20)          not null,
   IDCONSULTORIO        varchar(3)           not null,
   IDHISTORIA           varchar(10)          null,
   NOMBREMED            varchar(50)          not null,
   APELLIDOSMED         varchar(50)          not null,
   ESPECIALIDADMED      varchar(10)          not null,
   EXPERIENCIAMED       varchar(10)          not null,
   CELULARMED           varchar(10)          null,
   constraint PK_MEDICOS primary key nonclustered (CEDULAMED)
)
go

/*==============================================================*/
/* Index: ATIENDECONSULTORIO_FK                                 */
/*==============================================================*/
create index ATIENDECONSULTORIO_FK on MEDICOS (
IDCONSULTORIO ASC
)
go

/*==============================================================*/
/* Index: MODIFICAHISTORIA_FK                                   */
/*==============================================================*/
create index MODIFICAHISTORIA_FK on MEDICOS (
IDHISTORIA ASC
)
go

/*==============================================================*/
/* Table: PACIENTE                                              */
/*==============================================================*/
create table PACIENTE (
   CEDULAPAC            varchar(10)          not null,
   IDCAMA               varchar(10)          null,
   IDHISTORIA           varchar(10)          not null,
   NOMBRESPAC           varchar(50)          not null,
   APELLIDOSPAC         varchar(50)          not null,
   CELULARPAC           varchar(10)          not null,
   FECHANACPAC          datetime             not null,
   DIRECCIONPAC         varchar(50)          not null,
   GENEROPAC            varchar(1)           not null,
   ENTIDADSALUDPAC      varchar(50)          not null,
   AISLAMIENTOPAC       varchar(2)           not null,
   TIPOPAC              varchar(1)           not null,
   constraint PK_PACIENTE primary key nonclustered (CEDULAPAC)
)
go

/*==============================================================*/
/* Index: ASIGNACAMA_FK                                         */
/*==============================================================*/
create index ASIGNACAMA_FK on PACIENTE (
IDCAMA ASC
)
go

/*==============================================================*/
/* Index: TIENEHISTORIA_FK                                      */
/*==============================================================*/
create index TIENEHISTORIA_FK on PACIENTE (
IDHISTORIA ASC
)
go

alter table CAMA
   add constraint FK_CAMA_ASIGNAHAB_HABITACI foreign key (IDHABITACION)
      references HABITACION (IDHABITACION)
go

alter table CITA
   add constraint FK_CITA_ABREHISTO_HISTORIA foreign key (IDHISTORIA)
      references HISTORIACLINICA (IDHISTORIA)
go

alter table CITA
   add constraint FK_CITA_ASIGNACON_CONSULTO foreign key (IDCONSULTORIO)
      references CONSULTORIO (IDCONSULTORIO)
go

alter table CITA
   add constraint FK_CITA_PACIENTEC_PACIENTE foreign key (CEDULAPAC)
      references PACIENTE (CEDULAPAC)
go

alter table MEDICOS
   add constraint FK_MEDICOS_ATIENDECO_CONSULTO foreign key (IDCONSULTORIO)
      references CONSULTORIO (IDCONSULTORIO)
go

alter table MEDICOS
   add constraint FK_MEDICOS_MODIFICAH_HISTORIA foreign key (IDHISTORIA)
      references HISTORIACLINICA (IDHISTORIA)
go

alter table PACIENTE
   add constraint FK_PACIENTE_ASIGNACAM_CAMA foreign key (IDCAMA)
      references CAMA (IDCAMA)
go

alter table PACIENTE
   add constraint FK_PACIENTE_TIENEHIST_HISTORIA foreign key (IDHISTORIA)
      references HISTORIACLINICA (IDHISTORIA)
go

