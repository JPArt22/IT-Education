/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     5/31/2023 5:34:32 PM                         */
/*==============================================================*/


alter table CAMA
   drop constraint FK_CAMA_ASIGNAHAB_HABITACI;

alter table CITA
   drop constraint FK_CITA_ABREHISTO_HISTORIA;

alter table CITA
   drop constraint FK_CITA_ASIGNACON_CONSULTO;

alter table CITA
   drop constraint FK_CITA_PACIENTEC_PACIENTE;

alter table MEDICOS
   drop constraint FK_MEDICOS_ATIENDECO_CONSULTO;

alter table MEDICOS
   drop constraint FK_MEDICOS_MODIFICAH_HISTORIA;

alter table PACIENTE
   drop constraint FK_PACIENTE_ASIGNACAM_CAMA;

alter table PACIENTE
   drop constraint FK_PACIENTE_TIENEHIST_HISTORIA;

drop index ASIGNAHABITACION_FK;

drop table CAMA cascade constraints;

drop index PACIENTECITA_FK;

drop index ABREHISTORIA_FK;

drop index ASIGNACONSULTORIO_FK;

drop table CITA cascade constraints;

drop table CONSULTORIO cascade constraints;

drop table HABITACION cascade constraints;

drop table HISTORIACLINICA cascade constraints;

drop index MODIFICAHISTORIA_FK;

drop index ATIENDECONSULTORIO_FK;

drop table MEDICOS cascade constraints;

drop index TIENEHISTORIA_FK;

drop index ASIGNACAMA_FK;

drop table PACIENTE cascade constraints;

/*==============================================================*/
/* Table: CAMA                                                  */
/*==============================================================*/
create table CAMA 
(
   IDCAMA               VARCHAR2(10)         not null,
   IDHABITACION         VARCHAR2(10)         not null,
   ID2_PACIENTE         VARCHAR2(2)          not null,
   constraint PK_CAMA primary key (IDCAMA)
);

/*==============================================================*/
/* Index: ASIGNAHABITACION_FK                                   */
/*==============================================================*/
create index ASIGNAHABITACION_FK on CAMA (
   IDHABITACION ASC
);

/*==============================================================*/
/* Table: CITA                                                  */
/*==============================================================*/
create table CITA 
(
   IDCITA               VARCHAR2(15)         not null,
   IDCONSULTORIO        VARCHAR2(3)          not null,
   IDHISTORIA           VARCHAR2(10)         not null,
   CEDULAPAC            VARCHAR2(10)         not null,
   FECHACITA            DATE                 not null,
   HORACITA             DATE                 not null,
   ESPECIALIDADCITA     VARCHAR2(15)         not null,
   constraint PK_CITA primary key (IDCITA)
);

/*==============================================================*/
/* Index: ASIGNACONSULTORIO_FK                                  */
/*==============================================================*/
create index ASIGNACONSULTORIO_FK on CITA (
   IDCONSULTORIO ASC
);

/*==============================================================*/
/* Index: ABREHISTORIA_FK                                       */
/*==============================================================*/
create index ABREHISTORIA_FK on CITA (
   IDHISTORIA ASC
);

/*==============================================================*/
/* Index: PACIENTECITA_FK                                       */
/*==============================================================*/
create index PACIENTECITA_FK on CITA (
   CEDULAPAC ASC
);

/*==============================================================*/
/* Table: CONSULTORIO                                           */
/*==============================================================*/
create table CONSULTORIO 
(
   IDCONSULTORIO        VARCHAR2(3)          not null,
   ESTADOCONSULTORIO    VARCHAR2(2)          not null,
   constraint PK_CONSULTORIO primary key (IDCONSULTORIO)
);

/*==============================================================*/
/* Table: HABITACION                                            */
/*==============================================================*/
create table HABITACION 
(
   IDHABITACION         VARCHAR2(10)         not null,
   ESTADOHABITACION     VARCHAR2(1)          not null,
   constraint PK_HABITACION primary key (IDHABITACION)
);

/*==============================================================*/
/* Table: HISTORIACLINICA                                       */
/*==============================================================*/
create table HISTORIACLINICA 
(
   IDHISTORIA           VARCHAR2(10)         not null,
   FECHAHISTORIA        DATE                 not null,
   DATOSHISTORIA        VARCHAR2(1000)       not null,
   constraint PK_HISTORIACLINICA primary key (IDHISTORIA)
);

/*==============================================================*/
/* Table: MEDICOS                                               */
/*==============================================================*/
create table MEDICOS 
(
   CEDULAMED            VARCHAR2(20)         not null,
   IDCONSULTORIO        VARCHAR2(3)          not null,
   IDHISTORIA           VARCHAR2(10),
   NOMBREMED            VARCHAR2(50)         not null,
   APELLIDOSMED         VARCHAR2(50)         not null,
   ESPECIALIDADMED      VARCHAR2(10)         not null,
   EXPERIENCIAMED       VARCHAR2(10)         not null,
   CELULARMED           VARCHAR2(10),
   constraint PK_MEDICOS primary key (CEDULAMED)
);

/*==============================================================*/
/* Index: ATIENDECONSULTORIO_FK                                 */
/*==============================================================*/
create index ATIENDECONSULTORIO_FK on MEDICOS (
   IDCONSULTORIO ASC
);

/*==============================================================*/
/* Index: MODIFICAHISTORIA_FK                                   */
/*==============================================================*/
create index MODIFICAHISTORIA_FK on MEDICOS (
   IDHISTORIA ASC
);

/*==============================================================*/
/* Table: PACIENTE                                              */
/*==============================================================*/
create table PACIENTE 
(
   CEDULAPAC            VARCHAR2(10)         not null,
   IDCAMA               VARCHAR2(10),
   IDHISTORIA           VARCHAR2(10)         not null,
   NOMBRESPAC           VARCHAR2(50)         not null,
   APELLIDOSPAC         VARCHAR2(50)         not null,
   CELULARPAC           VARCHAR2(10)         not null,
   FECHANACPAC          DATE                 not null,
   DIRECCIONPAC         VARCHAR2(50)         not null,
   GENEROPAC            VARCHAR2(1)          not null,
   ENTIDADSALUDPAC      VARCHAR2(50)         not null,
   AISLAMIENTOPAC       VARCHAR2(2)          not null,
   TIPOPAC              VARCHAR2(1)          not null,
   constraint PK_PACIENTE primary key (CEDULAPAC)
);

/*==============================================================*/
/* Index: ASIGNACAMA_FK                                         */
/*==============================================================*/
create index ASIGNACAMA_FK on PACIENTE (
   IDCAMA ASC
);

/*==============================================================*/
/* Index: TIENEHISTORIA_FK                                      */
/*==============================================================*/
create index TIENEHISTORIA_FK on PACIENTE (
   IDHISTORIA ASC
);

alter table CAMA
   add constraint FK_CAMA_ASIGNAHAB_HABITACI foreign key (IDHABITACION)
      references HABITACION (IDHABITACION);

alter table CITA
   add constraint FK_CITA_ABREHISTO_HISTORIA foreign key (IDHISTORIA)
      references HISTORIACLINICA (IDHISTORIA);

alter table CITA
   add constraint FK_CITA_ASIGNACON_CONSULTO foreign key (IDCONSULTORIO)
      references CONSULTORIO (IDCONSULTORIO);

alter table CITA
   add constraint FK_CITA_PACIENTEC_PACIENTE foreign key (CEDULAPAC)
      references PACIENTE (CEDULAPAC);

alter table MEDICOS
   add constraint FK_MEDICOS_ATIENDECO_CONSULTO foreign key (IDCONSULTORIO)
      references CONSULTORIO (IDCONSULTORIO);

alter table MEDICOS
   add constraint FK_MEDICOS_MODIFICAH_HISTORIA foreign key (IDHISTORIA)
      references HISTORIACLINICA (IDHISTORIA);

alter table PACIENTE
   add constraint FK_PACIENTE_ASIGNACAM_CAMA foreign key (IDCAMA)
      references CAMA (IDCAMA);

alter table PACIENTE
   add constraint FK_PACIENTE_TIENEHIST_HISTORIA foreign key (IDHISTORIA)
      references HISTORIACLINICA (IDHISTORIA);

