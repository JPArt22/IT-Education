/*==============================================================*/
/* DBMS name:      ORACLE Version 11g                           */
/* Created on:     6/23/2023 1:57:16 AM                         */
/*==============================================================*/

/*==============================================================*/
/* Table: ACCIONESINDESEADASBITACORA                            */
/*==============================================================*/
create table ACCIONESINDESEADASBITACORA 
(
   IDACCION             VARCHAR2(10)         not null,
   IDUSUARIO            VARCHAR2(20),
   UBICACION            VARCHAR2(50),
   OBJETOAFECTADO       VARCHAR2(50),
   TIPOACCION           VARCHAR2(20),
   FECHAHORA            DATE,
   constraint PK_ACCIONESINDESEADASBITACORA primary key (IDACCION)
);

/*==============================================================*/
/* Table: BITACORA                                              */
/*==============================================================*/
create table BITACORA 
(
   IDBITACORA           VARCHAR2(10)         not null,
   IDUSUARIO            VARCHAR2(20),
   UBICACION            VARCHAR2(50),
   OBJETOAFECTADO       VARCHAR2(50),
   TIPOACCION           VARCHAR2(20),
   FECHAHORA            DATE,
   constraint PK_BITACORA primary key (IDBITACORA)
);

/*==============================================================*/
/* Table: CAMA                                                  */
/*==============================================================*/
create table CAMA 
(
   IDCAMA               VARCHAR2(10)         not null,
   HAB_IDHABITACION     VARCHAR2(10)         not null,
   ESTADOCAMA           VARCHAR2(2)          not null,
   FECHAOCUPACION       DATE                 not null,
   constraint PK_CAMA primary key (IDCAMA)
);

/*==============================================================*/
/* Index: ASIGNAHABITACION_FK                                   */
/*==============================================================*/
create index ASIGNAHABITACION_FK on CAMA (
   HAB_IDHABITACION ASC
);

/*==============================================================*/
/* Table: CITA                                                  */
/*==============================================================*/
create table CITA 
(
   IDCITA               VARCHAR2(15)         not null,
   PAC_CEDULAPAC        VARCHAR2(10)         not null,
   ESP_IDESPECIALIDAD   VARCHAR2(10)         not null,
   MED_CEDULAMED        VARCHAR2(20)         not null,
   CON_IDCONSULTORIO    VARCHAR2(10)         not null,
   HIS_IDHISTORIA       VARCHAR2(10)         not null,
   FECHACITA            DATE                 not null,
   ESTADOCITA           VARCHAR2(20),
   HORAINICIO           DATE,
   HORAFIN              DATE,
   HORACANCELACION      DATE,
   FECHACANCELACION     DATE,
   constraint PK_CITA primary key (IDCITA)
);

/*==============================================================*/
/* Index: ASIGNACONSULTORIO_FK                                  */
/*==============================================================*/
create index ASIGNACONSULTORIO_FK on CITA (
   CON_IDCONSULTORIO ASC
);

/*==============================================================*/
/* Index: PACIENTECITA_FK                                       */
/*==============================================================*/
create index PACIENTECITA_FK on CITA (
   PAC_CEDULAPAC ASC
);

/*==============================================================*/
/* Index: CREAHISTORIA_FK                                       */
/*==============================================================*/
create index CREAHISTORIA_FK on CITA (
   HIS_IDHISTORIA ASC
);

/*==============================================================*/
/* Index: ESPECIALIDADCITA_FK                                   */
/*==============================================================*/
create index ESPECIALIDADCITA_FK on CITA (
   ESP_IDESPECIALIDAD ASC
);

/*==============================================================*/
/* Index: CITAMEDICOS_FK                                        */
/*==============================================================*/
create index CITAMEDICOS_FK on CITA (
   MED_CEDULAMED ASC
);

/*==============================================================*/
/* Table: CONSULTORIO                                           */
/*==============================================================*/
create table CONSULTORIO 
(
   IDCONSULTORIO        VARCHAR2(10)         not null,
   ESP_IDESPECIALIDAD   VARCHAR2(10)         not null,
   ESTADOCONSULTORIO    VARCHAR2(2)          not null,
   constraint PK_CONSULTORIO primary key (IDCONSULTORIO)
);

/*==============================================================*/
/* Index: ESPECIALIDADCONSULTORIOS_FK                           */
/*==============================================================*/
create index ESPECIALIDADCONSULTORIOS_FK on CONSULTORIO (
   ESP_IDESPECIALIDAD ASC
);

/*==============================================================*/
/* Table: ENTIDADESSALUD                                        */
/*==============================================================*/
create table ENTIDADESSALUD 
(
   IDENTIDAD            VARCHAR2(10)         not null,
   CATEGORIAENTIDAD     VARCHAR2(50)         not null,
   NOMBREENTIDAD        VARCHAR2(50)         not null,
   constraint PK_ENTIDADESSALUD primary key (IDENTIDAD)
);

/*==============================================================*/
/* Table: ESPECIALIDAD                                          */
/*==============================================================*/
create table ESPECIALIDAD 
(
   IDESPECIALIDAD       VARCHAR2(10)         not null,
   NOMBREESPECIALIDAD   VARCHAR2(50)         not null,
   constraint PK_ESPECIALIDAD primary key (IDESPECIALIDAD)
);

/*==============================================================*/
/* Table: HABITACION                                            */
/*==============================================================*/
create table HABITACION 
(
   IDHABITACION         VARCHAR2(10)         not null,
   ESTADOHABITACION     VARCHAR2(1)          not null,
   AISLADAHAB           VARCHAR2(1)          not null,
   constraint PK_HABITACION primary key (IDHABITACION)
);

/*==============================================================*/
/* Table: HISTORIACLINICA                                       */
/*==============================================================*/
create table HISTORIACLINICA 
(
   IDHISTORIA           VARCHAR2(10)         not null,
   DATOSHISTORIA        CLOB,
   FECHAHISTORIA        DATE,
   constraint PK_HISTORIACLINICA primary key (IDHISTORIA)
);

/*==============================================================*/
/* Table: MEDICOS                                               */
/*==============================================================*/
create table MEDICOS 
(
   CEDULAMED            VARCHAR2(20)         not null,
   CON_IDCONSULTORIO    VARCHAR2(10)         not null,
   ESP_IDESPECIALIDAD   VARCHAR2(10)         not null,
   NOMBREMED            VARCHAR2(50)         not null,
   APELLIDOSMED         VARCHAR2(50)         not null,
   CELULARMED           VARCHAR2(10)         not null,
   constraint PK_MEDICOS primary key (CEDULAMED)
);

/*==============================================================*/
/* Index: ATIENDECONSULTORIO_FK                                 */
/*==============================================================*/
create index ATIENDECONSULTORIO_FK on MEDICOS (
   CON_IDCONSULTORIO ASC
);

/*==============================================================*/
/* Index: ESPECIALIDADMEDICOS_FK                                */
/*==============================================================*/
create index ESPECIALIDADMEDICOS_FK on MEDICOS (
   ESP_IDESPECIALIDAD ASC
);

/*==============================================================*/
/* Table: PACIENTE                                              */
/*==============================================================*/
create table PACIENTE 
(
   CEDULAPAC            VARCHAR2(10)         not null,
   UCI_IDUCI            VARCHAR2(10),
   ENT_IDENTIDAD        VARCHAR2(10)         not null,
   CON_IDCONSULTORIO    VARCHAR2(10),
   HIS_IDHISTORIA       VARCHAR2(10),
   HAB_IDHABITACION     VARCHAR2(10),
   CAM_IDCAMA           VARCHAR2(10),
   NOMBRESPAC           VARCHAR2(50)         not null,
   APELLIDOSPAC         VARCHAR2(50)         not null,
   CELULARPAC           VARCHAR2(10)         not null,
   FECHANACPAC          DATE                 not null,
   DIRECCIONPAC         VARCHAR2(50)         not null,
   GENEROPAC            VARCHAR2(1)          not null,
   AISLAMIENTOPAC       VARCHAR2(2)          not null,
   INACTIVOPAC          VARCHAR2(1)          not null,
   ATENDIDO             VARCHAR2(1)          not null,
   constraint PK_PACIENTE primary key (CEDULAPAC)
);

/*==============================================================*/
/* Index: ASIGNACAMA_FK                                         */
/*==============================================================*/
create index ASIGNACAMA_FK on PACIENTE (
   CAM_IDCAMA ASC
);

/*==============================================================*/
/* Index: TIENENENTIDAD_FK                                      */
/*==============================================================*/
create index TIENENENTIDAD_FK on PACIENTE (
   ENT_IDENTIDAD ASC
);

/*==============================================================*/
/* Index: ASIGNAUCI_FK                                          */
/*==============================================================*/
create index ASIGNAUCI_FK on PACIENTE (
   UCI_IDUCI ASC
);

/*==============================================================*/
/* Index: TIENEHISTORIA_FK                                      */
/*==============================================================*/
create index TIENEHISTORIA_FK on PACIENTE (
   HIS_IDHISTORIA ASC
);

/*==============================================================*/
/* Index: TIENECONSULTORIO_FK                                   */
/*==============================================================*/
create index TIENECONSULTORIO_FK on PACIENTE (
   CON_IDCONSULTORIO ASC
);

/*==============================================================*/
/* Index: TIENEHABITACION_FK                                    */
/*==============================================================*/
create index TIENEHABITACION_FK on PACIENTE (
   HAB_IDHABITACION ASC
);

/*==============================================================*/
/* Table: POLITICASCITAS                                        */
/*==============================================================*/
create table POLITICASCITAS 
(
   IDPOLITICA           VARCHAR2(3)          not null,
   NOMBREPOLITICA       VARCHAR2(50)         not null,
   DESCRIPCIONPOLITICA  CLOB                 not null,
   CAUSAPOLITICA        VARCHAR2(50)         not null,
   constraint PK_POLITICASCITAS primary key (IDPOLITICA)
);

/*==============================================================*/
/* Table: UCI                                                   */
/*==============================================================*/
create table UCI 
(
   IDUCI                VARCHAR2(10)         not null,
   ESTADOUCI            VARCHAR2(2)          not null,
   FECHAOCUPACION       DATE                 not null,
   constraint PK_UCI primary key (IDUCI)
);

/*CREACION DE VISTAS*/
CREATE VIEW VISTA_ESPECIALIDAD AS SELECT * FROM ESPECIALIDAD;
/
CREATE VIEW VISTA_CAMA AS SELECT * FROM CAMA;
/
CREATE VIEW VISTA_CITA AS SELECT * FROM CITA;
/
CREATE VIEW VISTA_CONSULTORIO AS SELECT * FROM CONSULTORIO;
/
CREATE VIEW VISTA_ENTIDADESSALUD AS SELECT * FROM ENTIDADESSALUD;
/
CREATE VIEW VISTA_HABITACION AS SELECT * FROM HABITACION;
/
CREATE VIEW VISTA_MEDICOS AS SELECT * FROM MEDICOS;
/
CREATE VIEW VISTA_PACIENTE AS SELECT * FROM PACIENTE;
/
CREATE VIEW VISTA_UCI AS SELECT * FROM UCI;
/
CREATE VIEW VISTA_HISTORIACLINICA AS SELECT * FROM HISTORIACLINICA;
/
CREATE VIEW VISTA_POLITICASCITAS AS SELECT * FROM POLITICASCITAS;
/
CREATE VIEW VISTA_BITACORA AS SELECT * FROM BITACORA;
/
CREATE VIEW VISTA_ACCIONESINDESEADAS AS SELECT * FROM ACCIONESINDESEADASBITACORA;
/


/*==============================================================*/
/* PROCEDURE INSERTARPACIENTE                                  */
/*==============================================================*/

CREATE OR REPLACE PROCEDURE INSERTARPACIENTE (
    CEDULAPAC       IN VARCHAR2,
    IDUCI           IN VARCHAR2,
    IDENTIDAD       IN VARCHAR2,
    IDCONSULTORIO   IN VARCHAR2,
    IDHISTORIA      IN VARCHAR2,
    IDHABITACION    IN VARCHAR2,
    IDCAMA          IN VARCHAR2,
    NOMBRESPAC      IN VARCHAR2,
    APELLIDOSPAC    IN VARCHAR2,
    CELULARPAC      IN VARCHAR2,
    FECHANACPAC     IN DATE,
    DIRECCIONPAC    IN VARCHAR2,
    GENEROPAC       IN VARCHAR2,
    AISLAMIENTOPAC  IN VARCHAR2,
    INACTIVOPAC     IN VARCHAR2,
    ATENDIDO        IN VARCHAR2
) AS
    entidad_count NUMBER;
BEGIN
    BEGIN
        -- Verificamos si la columna IDENTIDAD es NULL y generamos un error personalizado si es así
        IF IDENTIDAD IS NULL THEN
            RAISE_APPLICATION_ERROR(-20001, 'El paciente debe estar registrado en una entidad como beneficiario o cotizante.');
        END IF;
        
        -- Verificamos si la entidad existe en la tabla ENTIDADESSALUD
        SELECT COUNT(*) INTO entidad_count FROM ENTIDADESSALUD WHERE IDENTIDAD = IDENTIDAD;
        IF entidad_count = 0 THEN
            RAISE_APPLICATION_ERROR(-20002, 'La entidad especificada no existe.');
        END IF;
        
        -- Intentamos insertar el paciente en la tabla PACIENTE
        INSERT INTO PACIENTE (CEDULAPAC, UCI_IDUCI, ENT_IDENTIDAD, CON_IDCONSULTORIO, HIS_IDHISTORIA, HAB_IDHABITACION, CAM_IDCAMA, NOMBRESPAC, APELLIDOSPAC, CELULARPAC, FECHANACPAC, DIRECCIONPAC, GENEROPAC, AISLAMIENTOPAC, INACTIVOPAC, ATENDIDO)
        VALUES (CEDULAPAC, IDUCI, IDENTIDAD, IDCONSULTORIO, IDHISTORIA, IDHABITACION, IDCAMA, NOMBRESPAC, APELLIDOSPAC, CELULARPAC, FECHANACPAC, DIRECCIONPAC, GENEROPAC, AISLAMIENTOPAC, INACTIVOPAC, ATENDIDO);

        -- Si se llega a esta línea sin generar un error, significa que la inserción fue exitosa
        DBMS_OUTPUT.PUT_LINE('Paciente insertado correctamente.');
    END;
    EXCEPTION
        -- Verificamos si el error es de columna no nula
        WHEN OTHERS THEN
            IF SQLCODE = -20001 THEN
                -- Mostramos el mensaje personalizado para la columna no nula
                RAISE_APPLICATION_ERROR(-20001, 'El paciente debe estar registrado en una entidad como beneficiario o cotizante.');
            ELSIF SQLCODE = -20002 THEN
                -- Mostramos el mensaje personalizado para la restricción de clave externa
                RAISE_APPLICATION_ERROR(-20002, 'La entidad especificada no existe.');
            ELSE
                -- Si el error no es de columna no nula ni de restricción de clave externa, lanzamos el error original
                RAISE;
            END IF;
END;
/

/*==============================================================*/
/* PROCEDURE CREARCITA                                      */
/*==============================================================*/




/*==============================================================*/
/* PROCEDURE CANCELARCITA                                      */
/*==============================================================*/




/*==============================================================*/
/* PROCEDURE ACTIVARCITA                                       */
/*==============================================================*/

CREATE OR REPLACE PROCEDURE ActivarCita (
    IDCita IN VARCHAR2
)
AS
    FechaCita DATE;
    HoraCita TIMESTAMP;
    FechaActual DATE;
    HoraActual TIMESTAMP;
    HoraInicioActivacion TIMESTAMP;
    HoraFinActivacion TIMESTAMP;
BEGIN
    -- Obtener la fecha y hora actual
    FechaActual := TRUNC(SYSDATE);
    HoraActual := SYSDATE;

    -- Verificar si la cita existe
    SELECT FECHACITA, HORAINICIO
    INTO FechaCita, HoraCita
    FROM CITA
    WHERE IDCITA = IDCita;

    IF FechaCita IS NULL THEN
        DBMS_OUTPUT.PUT_LINE('La cita con el ID ' || IDCita || ' no existe.');
        RETURN;
    END IF;

    -- Calcular el rango de tiempo permitido para activar la cita
    HoraInicioActivacion := HoraCita - INTERVAL '3' HOUR;
    HoraFinActivacion := HoraCita + INTERVAL '5' MINUTE;

    -- Verificar si la cita se encuentra dentro del rango de tiempo permitido
    IF FechaCita = FechaActual THEN
        IF HoraActual < HoraInicioActivacion THEN
            DBMS_OUTPUT.PUT_LINE('No se puede activar la cita antes de las 3 horas programadas.');
            RETURN;
        ELSIF HoraActual > HoraFinActivacion THEN
            DBMS_OUTPUT.PUT_LINE('Ya ha pasado el tiempo permitido para activar la cita.');
            RETURN;
        END IF;
    ELSE
        DBMS_OUTPUT.PUT_LINE('No se puede activar la cita en la fecha actual.');
        RETURN;
    END IF;

    -- Actualizar el estado de la cita a "activada"
    UPDATE CITA
    SET ESTADOCITA = 'ACTIVADA'
    WHERE IDCITA = IDCita;

    DBMS_OUTPUT.PUT_LINE('La cita ha sido activada exitosamente.');
END;
/

/*==============================================================*/
/* PROCEDURE HISTORIAMED                                      */
/*==============================================================*/




/*==============================================================*/
/* PROCEDURE ASIGNARHABITACION                                      */
/*==============================================================*/





/*==============================================================*/
/* PROCEDURE ASIGNARUCI                                         */
/*==============================================================*/





/*==============================================================*/
/* TRIGGER MAXCAMASHAB                                          */
/*==============================================================*/





/*==============================================================*/
/* TRIGGER ACTUALIZARESTADOHABITACION                           */
/*==============================================================*/






/*==============================================================*/
/* TRIGGER BITACORA CAMA                                        */
/*==============================================================*/

CREATE SEQUENCE Seq_Bitacora
    START WITH 1
    INCREMENT BY 1;

CREATE OR REPLACE TRIGGER CAMA_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON CAMA
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.IDCAMA;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.IDCAMA;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.IDCAMA;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/


/*==============================================================*/
/* TRIGGER BITACORA HABITACION                                  */
/*==============================================================*/

-- Crear secuencia
CREATE SEQUENCE Seq_Bitacora2
    START WITH 1
    INCREMENT BY 1;

-- Crear trigger
CREATE OR REPLACE TRIGGER HABITACION_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON HABITACION
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.IDHABITACION;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.IDHABITACION;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.IDHABITACION;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/


/*==============================================================*/
/* TRIGGER BITACORA CITA                                        */
/*==============================================================*/

-- Crear secuencia
CREATE SEQUENCE Seq_Bitacora3
    START WITH 1
    INCREMENT BY 1;

-- Crear trigger
CREATE OR REPLACE TRIGGER CITA_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON CITA
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.IDCITA;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.IDCITA;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.IDCITA;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/

/*==============================================================*/
/* TRIGGER BITACORA CONSULTORIO                                 */
/*==============================================================*/

-- Crear secuencia
CREATE SEQUENCE Seq_Bitacora4
    START WITH 1
    INCREMENT BY 1;

-- Crear trigger
CREATE OR REPLACE TRIGGER CONSULTORIO_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON CONSULTORIO
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.IDCONSULTORIO;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.IDCONSULTORIO;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.IDCONSULTORIO;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/

/*==============================================================*/
/* TRIGGER BITACORA ENTIDADES                                   */
/*==============================================================*/

-- Crear secuencia
CREATE SEQUENCE Seq_Bitacora5
    START WITH 1
    INCREMENT BY 1;

-- Crear trigger
CREATE OR REPLACE TRIGGER ENTIDADESSALUD_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON ENTIDADESSALUD
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.IDENTIDAD;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.IDENTIDAD;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.IDENTIDAD;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/

/*==============================================================*/
/* TRIGGER BITACORA ESPECIALIDAD                                  */
/*==============================================================*/

-- Crear secuencia
CREATE SEQUENCE Seq_Bitacora6
    START WITH 1
    INCREMENT BY 1;

-- Crear trigger
CREATE OR REPLACE TRIGGER ESPECIALIDAD_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON ESPECIALIDAD
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.IDESPECIALIDAD;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.IDESPECIALIDAD;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.IDESPECIALIDAD;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/

/*==============================================================*/
/* TRIGGER BITACORA HISTORIAS                                   */
/*==============================================================*/

-- Crear secuencia
CREATE SEQUENCE Seq_Bitacora7
    START WITH 1
    INCREMENT BY 1;

-- Crear trigger
CREATE OR REPLACE TRIGGER HISTORIAS_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON HISTORIACLINICA
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.IDHISTORIA;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.IDHISTORIA;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.IDHISTORIA;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/

/*==============================================================*/
/* TRIGGER BITACORA MEDICOS                                       */
/*==============================================================*/

-- Crear secuencia
CREATE SEQUENCE Seq_Bitacora8
    START WITH 1
    INCREMENT BY 1;

-- Crear trigger
CREATE OR REPLACE TRIGGER MEDICOS_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON MEDICOS
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.CEDULAMED;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.CEDULAMED;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.CEDULAMED;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/

/*==============================================================*/
/* TRIGGER BITACORA PACIENTE                                     */
/*==============================================================*/

-- Crear secuencia
CREATE SEQUENCE Seq_Bitacora9
    START WITH 1
    INCREMENT BY 1;

-- Crear trigger
CREATE OR REPLACE TRIGGER PACIENTE_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON PACIENTE
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.CEDULAPAC;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.CEDULAPAC;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.CEDULAPAC;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/

/*==============================================================*/
/* TRIGGER BITACORA POLITICAS                                        */
/*==============================================================*/

-- Crear secuencia
CREATE SEQUENCE Seq_Bitacora10
    START WITH 1
    INCREMENT BY 1;

-- Crear trigger
CREATE OR REPLACE TRIGGER POLITICAS_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON POLITICASCITAS
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.IDPOLITICA;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.IDPOLITICA;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.IDPOLITICA;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/

/*==============================================================*/
/* TRIGGER BITACORA UCI                                       */
/*==============================================================*/

-- Crear secuencia
CREATE SEQUENCE Seq_Bitacora11
    START WITH 1
    INCREMENT BY 1;

-- Crear trigger
CREATE OR REPLACE TRIGGER UCI_BITACORA
AFTER INSERT OR UPDATE OR DELETE ON UCI
FOR EACH ROW
DECLARE
    v_IDBITACORA VARCHAR2(10);
    v_IDUSUARIO VARCHAR2(20);
    v_UBICACION VARCHAR2(50);
    v_OBJETOAFECTADO VARCHAR2(50);
    v_TIPOACCION VARCHAR2(20);
    v_FECHAHORA DATE;
BEGIN
    v_IDUSUARIO := USER; -- Guarda el usuario que hace el cambio
    v_UBICACION := SYS_CONTEXT('USERENV', 'HOST'); -- Obtener el nombre de la máquina

    IF INSERTING AND UPDATING THEN
        v_TIPOACCION := 'MODIFICACION';
        v_OBJETOAFECTADO := :OLD.IDUCI;
    ELSIF INSERTING THEN
        v_TIPOACCION := 'INSERCION';
        v_OBJETOAFECTADO := :NEW.IDUCI;
    ELSIF DELETING THEN
        v_TIPOACCION := 'BORRADO';
        v_OBJETOAFECTADO := :OLD.IDUCI;
    END IF;

    v_FECHAHORA := SYSDATE; -- Obtener la fecha y hora actual

    SELECT Seq_Bitacora.NEXTVAL INTO v_IDBITACORA FROM DUAL;

    INSERT INTO BITACORA (IDBITACORA, IDUSUARIO, UBICACION, OBJETOAFECTADO, TIPOACCION, FECHAHORA)
    VALUES (v_IDBITACORA, v_IDUSUARIO, v_UBICACION, v_OBJETOAFECTADO, v_TIPOACCION, v_FECHAHORA);
END;
/

/*==============================================================*/
/* TRIGGER ACCIONESINDESEADAS                                     */
/*==============================================================*/




/*==============================================================*/
/* TRIGGER ESTADOCITA                                  */
/*==============================================================*/

CREATE OR REPLACE TRIGGER ESTADOCITA
AFTER UPDATE OF ESTADOCITA ON CITA
FOR EACH ROW
BEGIN
    -- Verificar si se ha actualizado el estado de la cita a "activada"
    IF :NEW.ESTADOCITA = 'ACTIVADA' THEN
        -- Actualizar las citas que han pasado dos horas desde que se activaron
        UPDATE CITA
        SET ESTADOCITA = 'FINALIZADA'
        WHERE IDCITA = :NEW.IDCITA AND ESTADOCITA = 'ACTIVADA' AND (SYSDATE - :NEW.FECHACITA) * 24 >= 2;
    END IF;
END;
/

/*==============================================================*/
/* SECUENCIA PARA ACCIONESINDESEADAS                                     */
/*==============================================================*/

CREATE SEQUENCE Seq_Acciones
    START WITH 1
    INCREMENT BY 1;


/*==============================================================*/
/* VISTA PACIENTES ENTIDADES                                       */
/*==============================================================*/





/*==============================================================*/
/* VISTA CAMAS DISPONIBLES                                        */
/*==============================================================*/




/*==============================================================*/
/* VISTA CAMAS OCUPADAS                                     */
/*==============================================================*/




/*==============================================================*/
/* VISTA HAB DISPONIBLES                                      */
/*==============================================================*/

CREATE OR REPLACE VIEW VISTA_HABDISPONIBLES AS
SELECT *
FROM HABITACION
WHERE ESTADOHABITACION = '1';
/

/*==============================================================*/
/* VISTA HAB OCUPADAS                                    */
/*==============================================================*/




/*==============================================================*/
/* VISTA UCI DISPONIBLES                                   */
/*==============================================================*/

CREATE OR REPLACE VIEW VISTA_UCIDISPONIBLES AS
SELECT *
FROM UCI
WHERE ESTADOUCI = '1';
/

/*==============================================================*/
/* VISTA UCI OCUPADAS                                     */
/*==============================================================*/




/*==============================================================*/
/* VISTA PACIENTES HOSPITALIZADOS                                    */
/*==============================================================*/




/*==============================================================*/
/* VISTA CATEGORIAS                                */
/*==============================================================*/

CREATE OR REPLACE VIEW VISTA_Categorias AS
SELECT CATEGORIAENTIDAD
FROM ENTIDADESSALUD;
/

/*==============================================================*/
/* VISTA PACIENTES NO ATENDIDOS                                     */
/*==============================================================*/




/*==============================================================*/
/* VISTA PACIENTES INACTIVOS                                       */
/*==============================================================*/




/*==============================================================*/
/* VISTA COTIZANTES                                   */
/*==============================================================*/



/*==============================================================*/
/* VISTA BENEFICIARIOS                                   */
/*==============================================================*/





/*==============================================================*/
/* VISTA CONSULTORIOS DISPONIBLES                                */
/*==============================================================*/





/*==============================================================*/
/* VISTA CITAS CANCELADAS                             */
/*==============================================================*/





/*==============================================================*/

GRANT EXECUTE ON INSERTARPACIENTE TO PUBLIC;
GRANT EXECUTE ON CREARCITA TO PUBLIC;
GRANT EXECUTE ON CANCELARCITA TO PUBLIC;
GRANT EXECUTE ON ACTIVARCITA TO PUBLIC;
GRANT EXECUTE ON ACCEDERHISTORIAMED TO PUBLIC;
GRANT EXECUTE ON ASIGNARHABITACION TO PUBLIC;
GRANT EXECUTE ON ASIGNARUCI TO PUBLIC;
