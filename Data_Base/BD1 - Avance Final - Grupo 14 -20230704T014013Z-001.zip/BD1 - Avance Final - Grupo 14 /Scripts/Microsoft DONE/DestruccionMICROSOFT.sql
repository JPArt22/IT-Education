if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CAMA') and o.name = 'FK_CAMA_ASIGNAHAB_HABITACI')
alter table CAMA
   drop constraint FK_CAMA_ASIGNAHAB_HABITACI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CITA') and o.name = 'FK_CITA_ASIGNACON_CONSULTO')
alter table CITA
   drop constraint FK_CITA_ASIGNACON_CONSULTO
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CITA') and o.name = 'FK_CITA_CITAMEDIC_MEDICOS')
alter table CITA
   drop constraint FK_CITA_CITAMEDIC_MEDICOS
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CITA') and o.name = 'FK_CITA_CREAHISTO_HISTORIA')
alter table CITA
   drop constraint FK_CITA_CREAHISTO_HISTORIA
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CITA') and o.name = 'FK_CITA_ESPECIALI_ESPECIAL')
alter table CITA
   drop constraint FK_CITA_ESPECIALI_ESPECIAL
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CITA') and o.name = 'FK_CITA_PACIENTEC_PACIENTE')
alter table CITA
   drop constraint FK_CITA_PACIENTEC_PACIENTE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONSULTORIO') and o.name = 'FK_CONSULTO_ESPECIALI_ESPECIAL')
alter table CONSULTORIO
   drop constraint FK_CONSULTO_ESPECIALI_ESPECIAL
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MEDICOS') and o.name = 'FK_MEDICOS_ATIENDECO_CONSULTO')
alter table MEDICOS
   drop constraint FK_MEDICOS_ATIENDECO_CONSULTO
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('MEDICOS') and o.name = 'FK_MEDICOS_ESPECIALI_ESPECIAL')
alter table MEDICOS
   drop constraint FK_MEDICOS_ESPECIALI_ESPECIAL
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PACIENTE') and o.name = 'FK_PACIENTE_ASIGNACAM_CAMA')
alter table PACIENTE
   drop constraint FK_PACIENTE_ASIGNACAM_CAMA
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PACIENTE') and o.name = 'FK_PACIENTE_ASIGNAUCI_UCI')
alter table PACIENTE
   drop constraint FK_PACIENTE_ASIGNAUCI_UCI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PACIENTE') and o.name = 'FK_PACIENTE_TIENECONS_CONSULTO')
alter table PACIENTE
   drop constraint FK_PACIENTE_TIENECONS_CONSULTO
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PACIENTE') and o.name = 'FK_PACIENTE_TIENEHABI_HABITACI')
alter table PACIENTE
   drop constraint FK_PACIENTE_TIENEHABI_HABITACI
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PACIENTE') and o.name = 'FK_PACIENTE_TIENEHIST_HISTORIA')
alter table PACIENTE
   drop constraint FK_PACIENTE_TIENEHIST_HISTORIA
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PACIENTE') and o.name = 'FK_PACIENTE_TIENENENT_ENTIDADE')
alter table PACIENTE
   drop constraint FK_PACIENTE_TIENENENT_ENTIDADE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('ACCIONESINDESEADASBITACORA')
            and   type = 'U')
   drop table ACCIONESINDESEADASBITACORA
go

if exists (select 1
            from  sysobjects
           where  id = object_id('BITACORA')
            and   type = 'U')
   drop table BITACORA
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CAMA')
            and   name  = 'ASIGNAHABITACION_FK'
            and   indid > 0
            and   indid < 255)
   drop index CAMA.ASIGNAHABITACION_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CAMA')
            and   type = 'U')
   drop table CAMA
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CITA')
            and   name  = 'CITAMEDICOS_FK'
            and   indid > 0
            and   indid < 255)
   drop index CITA.CITAMEDICOS_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CITA')
            and   name  = 'ESPECIALIDADCITA_FK'
            and   indid > 0
            and   indid < 255)
   drop index CITA.ESPECIALIDADCITA_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CITA')
            and   name  = 'CREAHISTORIA_FK'
            and   indid > 0
            and   indid < 255)
   drop index CITA.CREAHISTORIA_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CITA')
            and   name  = 'PACIENTECITA_FK'
            and   indid > 0
            and   indid < 255)
   drop index CITA.PACIENTECITA_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CITA')
            and   name  = 'ASIGNACONSULTORIO_FK'
            and   indid > 0
            and   indid < 255)
   drop index CITA.ASIGNACONSULTORIO_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CITA')
            and   type = 'U')
   drop table CITA
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONSULTORIO')
            and   name  = 'ESPECIALIDADCONSULTORIOS_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONSULTORIO.ESPECIALIDADCONSULTORIOS_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONSULTORIO')
            and   type = 'U')
   drop table CONSULTORIO
go

if exists (select 1
            from  sysobjects
           where  id = object_id('ENTIDADESSALUD')
            and   type = 'U')
   drop table ENTIDADESSALUD
go

if exists (select 1
            from  sysobjects
           where  id = object_id('ESPECIALIDAD')
            and   type = 'U')
   drop table ESPECIALIDAD
go

if exists (select 1
            from  sysobjects
           where  id = object_id('HABITACION')
            and   type = 'U')
   drop table HABITACION
go

if exists (select 1
            from  sysobjects
           where  id = object_id('HISTORIACLINICA')
            and   type = 'U')
   drop table HISTORIACLINICA
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MEDICOS')
            and   name  = 'ESPECIALIDADMEDICOS_FK'
            and   indid > 0
            and   indid < 255)
   drop index MEDICOS.ESPECIALIDADMEDICOS_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('MEDICOS')
            and   name  = 'ATIENDECONSULTORIO_FK'
            and   indid > 0
            and   indid < 255)
   drop index MEDICOS.ATIENDECONSULTORIO_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('MEDICOS')
            and   type = 'U')
   drop table MEDICOS
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PACIENTE')
            and   name  = 'TIENEHABITACION_FK'
            and   indid > 0
            and   indid < 255)
   drop index PACIENTE.TIENEHABITACION_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PACIENTE')
            and   name  = 'TIENECONSULTORIO_FK'
            and   indid > 0
            and   indid < 255)
   drop index PACIENTE.TIENECONSULTORIO_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PACIENTE')
            and   name  = 'TIENEHISTORIA_FK'
            and   indid > 0
            and   indid < 255)
   drop index PACIENTE.TIENEHISTORIA_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PACIENTE')
            and   name  = 'ASIGNAUCI_FK'
            and   indid > 0
            and   indid < 255)
   drop index PACIENTE.ASIGNAUCI_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PACIENTE')
            and   name  = 'TIENENENTIDAD_FK'
            and   indid > 0
            and   indid < 255)
   drop index PACIENTE.TIENENENTIDAD_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PACIENTE')
            and   name  = 'ASIGNACAMA_FK'
            and   indid > 0
            and   indid < 255)
   drop index PACIENTE.ASIGNACAMA_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('PACIENTE')
            and   type = 'U')
   drop table PACIENTE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('POLITICASCITAS')
            and   type = 'U')
   drop table POLITICASCITAS
go

if exists (select 1
            from  sysobjects
           where  id = object_id('UCI')
            and   type = 'U')
   drop table UCI
go

/*==============================================================*/
/* DESTRUCCION DE OBJETOS                                       */
/*==============================================================*/
DROP VIEW VISTA_ACCIONESINDESEADAS;
DROP VIEW VISTA_BITACORA;
DROP VIEW VISTA_ESPECIALIDAD;
DROP VIEW VISTA_CAMA;
DROP VIEW VISTA_CITA;
DROP VIEW VISTA_CONSULTORIO;
DROP VIEW VISTA_ENTIDADESSALUD;
DROP VIEW VISTA_HABITACION;
DROP VIEW VISTA_MEDICOS;
DROP VIEW VISTA_PACIENTE;
DROP VIEW VISTA_UCI;
DROP VIEW VISTA_HISTORIACLINICA;
DROP VIEW VISTA_POLITICASCITAS;
DROP VIEW VISTA_CAMASDISPONIBLES;
DROP VIEW VISTA_CAMASOCUPADAS;
DROP VIEW VISTA_HABDISPONIBLES;
DROP VIEW VISTA_HABOCUPADAS;
DROP VIEW VISTA_UCIDISPONIBLES;
DROP VIEW VISTA_PACIENTESENTIDADES;
DROP VIEW VISTA_PACIENTESINACTIVOS;
DROP VIEW VISTA_PACIENTESPORATENDER;
DROP VIEW VISTA_PACIENTESUCI;
DROP TRIGGER VALIDAR_ENTIDAD;
DROP TRIGGER ACTUALIZAR_CITA;
DROP TRIGGER VERIFICAR_CONSULTORIO;
DROP PROCEDURE ASIGNARHABITACION;
DROP PROCEDURE ASIGNARUCI;
DROP PROCEDURE INSERTARPACIENTE;
DROP PROCEDURE CREARCITA;
DROP PROCEDURE ACTIVARCITA;
DROP PROCEDURE CANCELARCITA;
DROP TRIGGER MAXCAMAS_HAB;
DROP TRIGGER ACTUALIZARESTADO_HAB;
DROP TRIGGER CAMA_BITACORA;
DROP TRIGGER HABITACION_BITACORA;
DROP TRIGGER CITA_BITACORA;
DROP TRIGGER CONSULTORIO_BITACORA;
DROP TRIGGER ENTIDADESSALUD_BITACORA;
DROP TRIGGER ESPECIALIDAD_BITACORA;
DROP TRIGGER HISTORIACLINICA_BITACORA;
DROP TRIGGER MEDICOS_BITACORA;
DROP TRIGGER PACIENTE_BITACORA;
DROP TRIGGER POLITICASCITAS_BITACORA;
DROP TRIGGER UCI_BITACORA;
DROP SEQUENCE Seq_Bitacora;
DROP SEQUENCE Seq_Bitacora_2;
DROP SEQUENCE Seq_Acciones;
DROP TRIGGER ACCIONESIND_BITACORA;
DROP VIEW VISTA_COTIZANTES;
DROP VIEW VISTA_BENEFICIARIOS;
DROP VIEW VISTA_CONSULTORIOSDISP;
DROP VIEW VISTA_UCIOCUPADAS;
DROP VIEW VISTA_PACIENTESHOSPITALIZADOS;
DROP VIEW VISTA_CATEGORIAS;
DROP VIEW VISTA_CITASCANCELADAS;
DROP TRIGGER ESTADOCITA;
DROP PROCEDURE ACCEDERHISTORIAMED;