-- ----------------------------------------------------------------------------
--BD_-Avance_-grupo__-Req-Respuestas.sql
-- ----------------------------------------------------------------------------
-- Requerimientos y sus respuestas al problema de la Clínica Univerdad Nacional
-- Curso: Bases de Datos
-- Entrega: [Avance Final]
-- Grupo de trabajo: #14
-- Integrantes que participaron: Juan Sebastian Muñoz Lemus
Jhon Edinson Prieto Artunduaga
Nicolas Cortez Gutierrez
-- Versión para el servidor: v17
-- Fecha:22/6/2023
-- ----------------------------------------------------------------------------

/*
RB1.	El manejo de la “Clínica Universidad Nacional” se hace de acuerdo con
las leyes, decretos y demás reglamentación establecida para tal fin en la
República de Colombia.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB2.	El manejo de la “Clínica Universidad Nacional” se hace de acuerdo con
los estándares internacionales y en este momento está en el proceso de
acreditación internacional.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB3.	“Clínica Universidad Nacional” tiene en cuenta toda la reglamentación
vigente, especialmente la expedida por el Ministerio de salud.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB4.	La “Clínica Universidad Nacional” tiene establecido un marco para la
gestión ética que garantiza que la atención al paciente se lleve a cabo dentro
de las normativas comerciales, financieras, éticas y legales y que proteja a
los pacientes y sus derechos.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB5.	La “Clínica Universidad Nacional” forma y capacita a todo su personal
sobre sus roles para proporcionar al paciente una atención segura y efectiva.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB6.	La “Clínica Universidad Nacional” tiene un programa continuo de
gestión de riesgos para identificar y reducir eventos adversos inesperados y
otros riesgos para los pacientes y su personal.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB7.	En la “Clínica Universidad Nacional” existe un proceso para reunir
anualmente, los datos pertinentes sobre cada médico para su revisión por parte
del director del departamento médico. Esta revisión se elabora con el fin de
identificar las tendencias del ejercicio profesional que tienen un impacto en
la calidad de la atención y la seguridad del paciente.
*/
-- Respuesta

No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.
/*
RB8.	La “Clínica Universidad Nacional” inspecciona todos los edificios
donde se atiende a pacientes (citas y habitaciones) y cuenta con un plan para
reducir los riesgos evidentes y proporcionar instalaciones físicas seguras
para su personal, los pacientes, acompañantes, las familias y las visitas.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB9.	La “Clínica Universidad Nacional” ha planificado e implementado un
programa para asegurar que todos los ocupantes estén a salvo del fuego, el
humo u otras emergencias dentro de sus instalaciones.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB10.	“Clínica Universidad Nacional” tiene relaciones con todas las
Entidades de Salud del país, tanto en el régimen contributivo como en el
régimen subsidiado.
*/
-- Respuesta
Fue aplicado añadiendo todas las entidades de salud en el pais, en ambos regimenes.
Ejemplo: 
INSERT INTO jumunozle.VISTA_ENTIDADESSALUD VALUES('ENT01','beneficiario','Sanitas');
INSERT INTO jumunozle.VISTA_ENTIDADESSALUD VALUES('ENT02','cotizante','Sanitas');
INSERT INTO jumunozle.VISTA_ENTIDADESSALUD VALUES('ENT03','beneficiario','NuevaEPS');
INSERT INTO jumunozle.VISTA_ENTIDADESSALUD VALUES('ENT04','cotizante','NuevaEPS');
/*
RB11.	“Clínica Universidad Nacional” tiene en regla todas las pólizas de
seguros que son de tipo obligatorio.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB12.	“Clínica Universidad Nacional” contrata directamente al personal
médico, al personal administrativo, al personal científico, al personal de
laboratorios; para otros casos lo hace bajo la modalidad de prestación de
servicios de terceros, tales como la seguridad y vigilancia, aseo,
restaurante, manejo de parqueaderos y demás.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB13.	Algunas personas y organizaciones tienen relaciones con la “Clínica
Universidad Nacional” como voluntarios y personal de buena voluntad, sin que
ello signifique relación laboral alguna.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB14.	Todos los equipos que se encuentran en la “Clínica Universidad
Nacional” son propios. Cuando necesita de algún equipo que no está en sus
instalaciones, lo contrata como servicio externo.
*/
-- Respuesta

No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.
/*
RB15.	El personal administrativo de la “Clínica Universidad Nacional” está
muy pendiente de que toda la reglamentación y estándares se cumplan.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB16.	El reglamento interno de la “Clínica Universidad Nacional”, en este
momento se está elaborando y se espera que en dos meses esté totalmente
terminado y entre en vigencia en los primeros meses del año entrante.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB17.	El funcionamiento de la “Clínica Universidad Nacional” es autónomo e
independiente del manejo administrativo y académico de la Universidad Nacional.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB18.	Todas las personas y asociaciones que tienen relación con la “Clínica
Universidad Nacional” se comprometen a cumplir las reglas, estatutos y
reglamentos de la “Clínica Universidad Nacional”, así como todas sus
circulares, directrices y decisiones.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB19.	La “Clínica Universidad Nacional” cuenta con personas que tienen la
experiencia, el conocimiento y las habilidades adecuadas para agregar y
analizar sistemáticamente los datos.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB20.	Con el fin de llegar a conclusiones y tomar decisiones acertadas, en
la “Clínica Universidad Nacional” entienden que deben agregarse y analizarse
datos y transformarlos en información útil.
*/
-- Respuesta

No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.
/*
RB21.	La “Clínica Universidad Nacional” entiende y valora que el análisis de
datos involucra a personas que entienden la gestión de la información, están
capacitadas en métodos de análisis de datos agregados y saben cómo usar
herramientas estadísticas.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB22.	En la “Clínica Universidad Nacional” las personas responsables de los
procesos administrativos, procesos clínicos o producción de informes y
resultados que se miden, son informadas de los resultados del análisis de
datos. Estas personas pueden pertenecer al área clínica, al área de gestión o
cualquier otra área dentro de la “Clínica Universidad Nacional” donde ellos se
necesiten.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB23.	La “Clínica Universidad Nacional” valora el análisis de datos, pues
entiende que tal análisis proporciona una retroalimentación constante de
información sobre gestión de la calidad, para ayudar a tomar decisiones
acertadas y a mejorar continuamente los procesos clínicos y de gestión.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB24.	Una altísima prioridad para la “Clínica Universidad Nacional” es la
correcta identificación de los pacientes.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB25.	Para la “Clínica Universidad Nacional” la correcta identificación de
todo el personal médico, es una altísima prioridad.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB26.	También es prioridad, tener una comunicación efectiva, es decir,
oportuna, precisa, completa, inequívoca y comprendida por quien la recibe.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB27.	Asignar el consultorio correcto, con el procedimiento correcto y al
paciente correcto, cuando se trabajan citas médica, es una prioridad.
*/
-- Respuesta
Fue aplicado con el procedimiento CREARCITA, en el cual se manejan todos los errores posibles, y se maneja la correcta asignacion
de citas, procedimientos y a los pacientes correctos.

/*
RB28.	Asignar la habitación correcta, con el procedimiento correcto y al
paciente correcto, cuando hay pacientes hospitalizados, es prioridad.
*/
-- Respuesta
Fue aplicado con los procedimiento ASIGNARHABITACION, y ASIGNARUCI, para cada caso se manejan los errores y se manejan las correcta
asignacion de procedimientos, camas y pacientes.

/*
RB29.	La “Clínica Universidad Nacional” desea planificar e implementar
procesos para inspeccionar, probar y mantener equipo médico.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB30.	Para la “Clínica Universidad Nacional” también es muy importante
reducir el riesgo de infecciones, tanto para los pacientes, como para los
funcionarios de la clínica.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB31.	En la “Clínica Universidad Nacional” los pacientes con necesidades de
emergencia, urgentes o inmediatas tienen atención prioritaria.
*/
-- Respuesta
No aplica, ya que los servicios de urgencia no eran necesarios en esta etapa del proyecto.

/*
RB32.	La determinación de emergencia, urgencia, prioridad y/o atención
inmediata se hace en la “Clínica Universidad Nacional” mediante un riguroso
protocolo médico.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB33.	Las citas médicas las solicita un paciente y las asigna, de común
acuerdo, el personal de programación de citas, según disponibilidad de
consultorio y médico.
*/
-- Respuesta
Fue aplicado, la cita la pide un paciente, y el personal mediante el procedimiento CREARCITA asigna la cita (el procedimiento
tiene en cuenta la disponibilidad de consultorios y medicos).

/*
RB34.	La agenda para citas está disponible desde el día en que el paciente
hace la solicitud y hay posibilidad de programar la cita médica en los tres
(3) meses siguientes.
*/
-- Respuesta
Fue aplicado, en el procedimiento CREARCITA se pueden agendar las citas tanto el mismo dia que se solicita, hasta maximo 3 meses 
desde el dia que se solicita, y si se solicita a mas de 3 meses da como error que no se puede crear una cita hasta despues de 3 
meses.
/*
RB35.	Un paciente puede cancelar o modificar una cita médica acordada, hasta
veinticuatro horas (24h) antes de su hora programada, para que no cause
penalización.
*/
-- Respuesta
Fue parcialmente aplicado con el procedimiento CANCELARCITA,el paciente solo puede cancelar la cita, no modificarla, y no hay 
penalizacion si se cancela 24 horas antes de la hora programada. 
/*
RB36.	Tan pronto un paciente cancela una cita médica, queda disponible para
que se pueda programar a otro paciente.
*/
-- Respuesta
Fue aplicado con el procedimiento CANCELARCITA, si se cancela la cita, ESTADOCITA de la cita creada pasa a cancelada, y el horario
escogido queda disponible para que cualquier otro paciente programe una cita.

/*
RB37.	Un médico puede cancelar una cita médica, siguiendo el proceso
administrativo establecido. En este caso, las personas de programación de
citas acuerdan con el paciente la solución a este impase (por ejemplo acuerdan
pasar al paciente a una lista de espera, o pasarlo para que otro médico lo
atienda, o atenderlo con un retraso, o	reprogramar para otra fecha, o
cualquier otro acuerdo factible).
*/
-- Respuesta
No fue aplicado, ya que no encontramos la forma de aplicarlo a las bases de datos.

/*
RB38.	Una cita médica se puede cancelar en cualquier momento ante un caso
excepcional, como por ejemplo, un terremoto, un desastre natural, un incendio,
indisponibilidad del consultorio. En estos casos, el personal de programación
de citas acuerda con el paciente la solución a esta eventualidad.
*/
-- Respuesta
Lo consideramos como no aplica debido a que en este sistema no se tiene en cuenta los casos de fuerza mayor como por ejemplo desastres
naturales, indisponibilidad de medicos/consultorios, etc.

/*
RB39.	La “Clínica Universidad Nacional” tiene en cuenta las necesidades de
atención de los pacientes cuando hay listas de espera y/o retrasos para
acceder a servicios.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB40.	Un tipo de lista de espera, se elabora para colocar en cola de
atención a pacientes que necesitan hospitalización urgente y no hay
disponibilidad en la “Clínica Universidad Nacional”.
*/
-- Respuesta
No fue aplicado, ya que no encontramos la forma de aplicarlo a nuestro proyecto.

/*
RB41.	Otro tipo de cola de espera, se hace con los pacientes que necesitan
de forma urgente una cita médica con un determinado médico y no hay
disponibilidad.
*/
-- Respuesta
No fue aplicado, ya que no encontramos la forma de aplicarlo a nuestro proyecto.

/*
RB42.	Una tercera lista de espera, funciona con los pacientes que estando en
las instalaciones de la “Clínica Universidad Nacional”, no se atienden debido
a que se presenta un imprevisto y esperan ser atendidos en ese mismo día, si
algún médico tiene disponibilidad para atenderlo, por ejemplo aprovechando el
espacio que deja un paciente que falta a una cita. Esta lista sólo vale para
atención en el día en que ella se elabora.
*/
-- Respuesta
No fue aplicado, ya que no encontramos la forma de aplicarlo a nuestro proyecto.

/*
RB43.	Los médicos tienen la obligación de cumplir con las asignaciones que
se programen en la “Clínica Universidad Nacional”. Actualmente, esta
programación siempre se hace de común acuerdo entre la administración y los
médicos y dentro de los términos de contratación.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB44.	Los pacientes tienen la obligación de cumplir con las asignaciones que
se programen en la “Clínica Universidad Nacional”, relacionadas con citas
médicas.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB45.	Los pacientes tienen la obligación de acatar las asignaciones que se
programen en la “Clínica Universidad Nacional”, relacionadas con la asignación
de habitaciones, en el caso de hospitalización.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB46.	Pacientes que incumplan citas programadas, tienen una penalización de
tipo económica.
*/
-- Respuesta
Lo consideramos como no aplica, debido a que en este sistema no tuvimos en cuenta requerimientos relacionados con dinero, 
penalizaciones y demas.

/*
RB47.	El monto de la penalización económica aplicada a un paciente que
incumple una cita médica está determinada por una tabla que anualmente elabora
la “Clínica Universidad Nacional” en el mes de enero de cada año y que depende
de la categoría de cada paciente.
*/
-- Respuesta
Lo consideramos como no aplica, debido a que en este sistema no tuvimos en cuenta requerimientos relacionados con dinero, 
penalizaciones y demas.

/*
RB48.	Las citas que no se puedan efectuar por causas de fuerza mayor, por
inconvenientes no salvables, porque son reprogramadas por el personal de
asignación de citas y todas las que provengan de parte de la “Clínica
Universidad Nacional” no tienen sanción.
*/
-- Respuesta
Lo consideramos como no aplica debido a que en este sistema no se tiene en cuenta los casos de fuerza mayor y tampoco se tiene en
cuenta los temas relacionados con dinero.

/*
RB49.	La categoría de un cotizante la determina la Entidad de Salud y la
categoría de un beneficiario es la misma que tiene el cotizante del cual
depende el beneficiario.
*/
-- Respuesta
Fue aplicado en la tabla ENTIDADESSALUD, donde la categoria del paciente se define dependiendo de con cual entidad este relacionada
el paciente.

/*
RB50.	La “Clínica Universidad Nacional” puede imponer sanciones a los
médicos que incumplan la atención de las citas médicas que se le programen, de
acuerdo con la reglamentación vigente.
*/
-- Respuesta
Lo consideramos como no aplica, debido a que en este sistema no tuvimos en cuenta requerimientos relacionados con dinero, 
penalizaciones y demas.


/*
RB51.	En la actualidad, al médico se le aplica una sanción económica que
corresponde al diez por ciento (10%) de su salario mensual, por cada cita
médica programada que él incumpla.
*/
-- Respuesta
Lo consideramos como no aplica, debido a que en este sistema no tuvimos en cuenta requerimientos relacionados con dinero, 
penalizaciones y demas.

/*
RB52.	Si un médico, sin excusa aceptada, deja de atender diez (10) o más
citas médicas programadas en un período de seis (6) meses, es causal de
cancelación inmediata del contrato de trabajo.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB53.	“Clínica Universidad Nacional” tiene una lista de situaciones que se
consideran de fuerza mayor, para los casos de incumplimiento de citas.
*/
-- Respuesta
Lo consideramos como no aplica debido a que en este sistema no se tiene en cuenta los casos de fuerza mayor.

/*
RB54.	Si un médico/paciente se retira o no se puede llevar a cabo o se
suspende una cita médica por causas de fuerza mayor, el personal
administrativo de asignación de citas decide qué medida adopta, de manera
discrecional y sin consultar con ningún otro órgano de la “Clínica Universidad
Nacional”.
*/
-- Respuesta
Lo consideramos como no aplica debido a que en este sistema no se tiene en cuenta los casos de fuerza mayor.

/*
RB55.	Si no se lleva a cabo una cita médica o si se suspende de forma
definitiva por causas de fuerza mayor, lo habitual es que se ordene su
reprogramación sin penalizaciones.
*/
-- Respuesta
Lo consideramos como no aplica debido a que en este sistema no se tiene en cuenta los casos de fuerza mayor.

/*
RB56.	Ante una eventualidad menor, el personal de citas decide qué medida
aplicar, por ejemplo abre una lista de espera, reprograma para el mismo día o
acuerda una nueva cita en un día diferente, sin penalización.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB57.	En caso de falta de fluido eléctrico, la atención de citas continúa
sin parar, y los médicos tienen que hacer todo el registro de la cita de forma
manual, siempre y cuando esto sea factible.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB58.	Todo lo registrado por el médico de forma manual, se tiene que
procesar en el sistema digital, tan pronto como se supere el evento que lo
activó.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB59.	Todos los eventos que causen suspensión, retrasos, congestión o
similares en la prestación del servicio, tienen que ser registrados en el
sistema digital, tan pronto sea posible hacerlo.
*/
-- Respuesta
Lo consideramos como no aplica ya que en esta etapa del proyecto solo estabamos concentrados en citas, asignacion de habitaciones,
identifacion de pacientes, medicos, etc.

/*
RB60.	Uno de los compromisos básicos que tienen concertados, las Entidades
de Salud con la “Clínica Universidad Nacional”, es la de tener al día toda la
información de cotizantes y de sus beneficiarios. Y el compromiso de la
“Clínica Universidad Nacional” con las Entidades de Salud, es la de procesar
toda esa información tan pronto la reciban y así prestar todos los servicios
acordados.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB61.	Las Entidades de Salud son las responsables de verificar que sus
afiliados cumplan con todos los requisitos establecidos para su atención en la
“Clínica Universidad Nacional”.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB62.	Normalmente, cada cita médica programada tiene una duración de 20
minutos.
*/
-- Respuesta
Fue aplicado en el procedimiento CREARCITA, en el cual a la cita creada se le agregan minutos a la hora seleccionada. Con la 
siguiente sentencia: SET @HORAFIN = DATEADD(MINUTE, 20, @HORAINICIO);

/*
RB63.	A un paciente se le puede asignar una cita doble, es decir, que su
consulta va a durar 40 minutos, siempre y cuando el médico tratante así lo
indique de forma explícita al momento en que le indica al paciente que
solicite una próxima cita.
*/
-- Respuesta
Fue aplicado en el procedimiento CREARCITA, el paciente puede solicitar cita doble siempre y cuando el doctor no tenga el horario
ocupado despues de la primera cita asignada.

/*
RB64.	Si una cita se alarga, por alguna razón aceptable, el médico puede
tomar una decisión con respecto de las citas siguientes e informará de este
hecho al personal de asignación de citas.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.
/*
RB65.	El personal de apoyo que asiste al médico en las citas con sus
pacientes, como por ejemplo el personal de enfermería, es gestionado por la
dependencia que maneja personal en la “Clínica Universidad Nacional”.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos, y ademas, en esta etapa del proyecto no era
necesario aplicar temas relaciones con enfermeria.

/*
RB66.	La “Clínica Universidad Nacional” únicamente atiende a los pacientes
formalmente inscritos y que están activos en el sistema.
*/
-- Respuesta
Fue aplicado en todos los procedimientos, si al asignar una habitacion, uci, o una cita a un paciente que no este inscrito con su
cedula en el sistema, tenemos como error que el paciente no existe.
Como por ejemplo:    
    -- Verificar si el paciente existe
    IF NOT EXISTS (SELECT 1 FROM PACIENTE WHERE CEDULAPAC = @CEDULAPAC)
    BEGIN
        RAISERROR('El paciente especificado no existe.', 16, 1);
        RETURN;
    END;

/*
RB67.	La “Clínica Universidad Nacional” únicamente programa a los médicos
que tiene en su plantilla de personal médico, respetando su contrato,
permisos, vacaciones y otras actividades que tenga que desarrollar.
*/
-- Respuesta
Fue aplicado en el procedimiento CREARCITA, el cual solo asigna los medicos que estan registrados en el sistema.

/*
RB68.	La “Clínica Universidad Nacional” únicamente programa, para las citas
médicas, los consultorios destinados para tal fin y de acuerdo con la
especialidad del médico.
*/
-- Respuesta
Fue aplicado en el procedimiento CREARCITA, el cual solo asigna los consultorios y medicos destinados para la respectiva
especialidad solicitada.

/*
RB69.	La “Clínica Universidad Nacional” únicamente programa las habitaciones
y camas que tiene designadas para atender a los pacientes hospitalizados.
*/
-- Respuesta
Fue aplicado en el procedimiento ASIGNARHABITACION el cual solo asigna habitaciones y camas disponibles en el sistema.

/*
RB70.	La “Clínica Universidad Nacional” únicamente programa las Unidades de
cuidados intensivos, UCI, que tiene designadas para pacientes que por su
condición especial de salud, así lo requieran.
*/
-- Respuesta
Fue aplicado en el procedimiento ASIGNARUCI el cual solo asigna UCIs disponibles en el sistema.

/*
RB71.	Los consultorios para citas médicas, únicamente se asignan para una y
solo una especialidad.
*/
-- Respuesta
Fue aplicado, en la tabla consultorios, cada consultorio tiene su propia especialidad y no pueden ser asignados para otra 
especialidad.

/*
RB72.	Si un consultorio queda inhabilitado, de inmediato tienen que
reprogramarse las citas en otro consultorio o hacer una lista de espera o
reprogramarse para otro día y a los médicos y a los pacientes, darles un aviso
de tal cambio.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB73.	Las habitaciones de la “Clínica Universidad Nacional”, son para una,
dos, tres o máximo cuatro pacientes.
*/
-- Respuesta
Fue aplicado, mediante el trigger maxcamas_hab, que permite que solo se puedan insertar 4 camas maximo por habitacion, si se
intentan añadir mas, sale como error que no se pueden agregar mas de 4 camas a una habitacion.

/*
RB74.	Para la asignación de habitación a un paciente, la “Clínica
Universidad Nacional” tiene una lista de condiciones para su asignación, por
ejemplo, pacientes que deban estar en aislamiento, no pueden estar en
habitaciones donde hay otros pacientes.
*/
-- Respuesta
Fue parcialmente aplicado, solo se tuvo en cuenta que si el paciente necesita estar en aislamiento, solo se le asignara una habitacion
para pacientes en aislamiento.
/*
RB75.	Durante el tiempo que un paciente está hospitalizado, la “Clínica
Universidad Nacional” le asigna un profesional calificado, el cual se
identifica	como el responsable de su atención y es el encargado de coordinar
la atención del paciente por otros médicos, otro personal de la clínica y
asistencia a exámenes, cuando así lo requiera el tratamiento que se le aplica.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB76.	La “Clínica Universidad Nacional” tiene un proceso para la gestión y
el seguimiento de los pacientes que solicitan alta voluntaria en contra del
consejo médico.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB77.	Para la “Clínica Universidad Nacional” cada paciente es único, con sus
propias necesidades, fortalezas, valores y creencias, por lo tanto ella
trabaja de forma continua para establecer la confianza y la comunicación
abierta con los pacientes y para comprender y proteger los valores culturales,
psicosociales y espirituales de cada paciente.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB78.	La información de pacientes, médicos y personal administrativo de
“Clínica Universidad Nacional” es confidencial y se maneja de acuerdo a las
leyes de protección de datos vigente.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB79.	Para la “Clínica Universidad Nacional” la intimidad del paciente es
importante, en especial durante procedimientos clínicos, exploraciones y
tratamientos.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB80.	La “Clínica Universidad Nacional” entiende que los pacientes pueden
requerir intimidad respecto a otros miembros del personal, otros pacientes e
incluso respecto a otros miembros de su familia. Además, entiende que algunos
pacientes no deseen ser fotografiados, grabados ni entrevistados en
evaluaciones. También entiende que si bien existen algunos enfoques comunes
para garantizar la intimidad de los pacientes, otros pacientes tienen
expectativas y necesidades de intimidad, diferentes o adicionales según la
situación, y estas expectativas y necesidades pueden cambiar con el tiempo. A
medida que el personal de la clínica atiende a los pacientes, consulta sobre
sus necesidades y expectativas de intimidad durante la atención. Esta
comunicación se entiende entre miembros del personal de la clínica, otras
comunidades y los pacientes.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB81.	La “Clínica Universidad Nacional” entiende que la información médica y
demás información sanitaria recolectada y documentada es importante para
comprender al paciente, comprender sus necesidades y con estos soportes
sustentar el mejor tratamiento, atención y servicio al paciente. La “Clínica
Universidad Nacional” es consciente de su valor, pero  respeta esta
información, le da un tratamiento de alta confidencialidad y tiene políticas y
procedimientos que protegen dicha información contra pérdida y/o uso indebido,
todo ajustado con las normas internacionales y las leyes vigentes en el país.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB82.	La información que la “Clínica Universidad Nacional” suministra, tanto
a nivel interno como a nivel externo, se rige por estrictos procedimientos y
políticas, todas ajustadas a los estándares internacionales, leyes y
reglamentaciones vigentes pertinentes.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB83.	El personal de la “Clínica Universidad Nacional” respeta la
confidencialidad del paciente, no suministrando información confidencial.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB84.	El personal de la “Clínica Universidad Nacional” conoce las políticas,
procedimientos, estándares internacionales, leyes y reglamentaciones que rigen
la confidencialidad de la información y explica a los pacientes los sistemas
de la clínica para respetar la confidencialidad de la información.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB85.	La “Clínica Universidad Nacional” informa a los pacientes sobre cuándo
y bajo qué circunstancias se divulga información y el sistema y procedimientos
que se siguen para obtener su consentimiento.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB86.	La “Clínica Universidad Nacional” cuenta con una política y
procedimientos que establecen si los pacientes tienen acceso a su información
médico-sanitaria, cuándo está permitido y la forma de acceder a ella.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB87.	La “Clínica Universidad Nacional” tiene personal especializado para la
atención a pacientes que solicitan cita médica.
*/
-- Respuesta
Lo consideramos como aplicado, ya que la clinica solo asigna personal (medicos) especializados para las necesidades de los pacientes.

/*
RB88.	Los pacientes o cualquier persona que lo haga a nombre de ellos, puede
solicitar cita con el médico general o con un especialista de acuerdo con las
normas establecidas en la “Clínica Universidad Nacional”.
*/
-- Respuesta
Fue aplicado con el procedimiento CREARCITA, el cual recibe la cedula del paciente y la especialidad que solicita el paciente.

/*
RB89.	La asignación de una cita a un paciente depende de la disponibilidad
de consultorios y/o médicos y/o normas establecidas. Una vez asignada la cita,
se le comunica este evento a la persona que solicita la cita y al paciente se
le envía a su cuenta de correo electrónico un comunicado informándolo de la
cita.
*/
-- Respuesta
Fue parcialmente aplicado, en el procedimiento CREARCITA se tiene en cuenta la disponibilidad de consultorios y medicos,
lo que no puede ser aplicado es el envio del comunicado al correo electronico al paciente.

/*
RB90.	Para casos especiales, eventos inesperados y para el manejo de
excepciones, la “Clínica Universidad Nacional” tiene supervisores del personal
de asignación de citas, los cuales deciden sobre el proceso o procedimiento a
seguir con las citas programadas o a programar.
*/
-- Respuesta
Lo consideramos como no aplica debido a que en este sistema no se tiene en cuenta los casos de fuerza mayor, casos especiales,
y excepciones.

/*
RB91.	En la “Clínica Universidad Nacional” las citas médicas se programan
desde las 6a.m. y la última a las 10:40p.m., de lunes a sábado. Los domingos y
feriados no hay atención.
*/
-- Respuesta
Fue aplicado en el procedimiento CREARCITA, donde las citas solo pueden ser programas de 6am a 10:40pm, si se intenta asignar 
afuera del horario sale un error diciendo que el horario no esta permitido.

/*
RB92.	A los médicos que atienden citas médicas, se programan siempre de
forma continua, típicamente en un solo consultorio y de acuerdo con su
especialidad.
*/
-- Respuesta
Fue aplicado, cada medico tiene un solo consultorio y especialidad segun la tabla MEDICOS.

/*
RB93.	La “Clínica Universidad Nacional” tiene un sitio destinado al descanso
y reunión de los médicos, enfermeras y personal administrativo, el cual pueden
utilizar durante el tiempo en que no se encuentran realizando sus funciones.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB94.	Normalmente a los médicos de medio tiempo y tiempo completo que
únicamente atienden citas médicas, durante su jornada de trabajo, pueden
disfrutar de un descanso de veinte minutos (20 min.), el cual lo programan de
común acuerdo el médico con el personal administrativo; en todo caso, teniendo
en cuenta la política de la “Clínica Universidad Nacional”, la cual establece
que dicho descanso es obligatorio después de atender cinco citas continuas, es
decir, después de una hora y cuarenta minutos (1h:40min) de atención
continua,  no antes de atender por lo menos una cita médica y con la
posibilidad de tomar descansos seguidos (por ejemplo, utilizados para ir a
almorzar).
*/
-- Respuesta
No lo consideramos como aplicable, ya que en esta etapa del proyecto no se tienen en cuenta los descansos para los medicos,
ni politicas de la Clinica, aparte los acuerdos con el personal administrativo estan afuera del entorno de las bases de datos.

/*
RB95.	Cada médico de la “Clínica Universidad Nacional”, sólo atiende a
pacientes con citas, en una y solo una especialidad, de acuerdo con su
contrato.
*/
-- Respuesta
Fue aplicado en el procedimiento CREARCITA y en la tabla MEDICOS, cada medico solo tiene una sola especialidad, y en el
procedimiento solo se asignan medicos cuando se crean la citas.

/*
RB96.	Los médicos que laboran con la “Clínica Universidad Nacional” tienen
contrato a término indefinido como médico general o en una y solo una
especialidad
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB97.	Los médicos que laboran con la “Clínica Universidad Nacional” tienen
un sueldo mensual que la Clínica paga en pesos colombianos, el cual se aumenta
automáticamente en un 4.5% cada vez que cumplen un año más de vinculación con
la Clínica.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos, aparte no tomamos en cuenta lo relacionado
con el dinero.

/*
RB98.	La “Clínica Universidad Nacional” solamente contrata personal médico
con cuatro o más años de experiencia (que cuentan a partir de la fecha de
grado).
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB99.	La “Clínica Universidad Nacional” tiene un proceso para recabar,
verificar y evaluar las cualificaciones (habilitación, formación, capacitación
y experiencia) del personal médico habilitado para prestar atención al
paciente sin supervisión. Se entiende como personal médico a los médicos,
odontólogos y otros profesionales sanitarios con licencia para la práctica
independiente (sin supervisión) y que proporcionan servicios preventivos,
curativos, restauradores, quirúrgicos, de rehabilitación o cualquier otro tipo
de servicios médicos u odontológicos a los pacientes.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB100.	A un paciente se le pueden programar, en un solo día, una o más citas
médicas, siempre y cuando no haya cruces de horario.
*/
-- Respuesta
Fue aplicado en el procedimiento CREARCITA, a un paciente se le pueden asignar varias citas entre varios medicos, siempre y cuando
los medicos no tengan citas asignadas en los horarios solicitados.

/*
RB101.	Los pacientes tienen que activar su cita, antes de la hora programada,
con el personal que se designe para tal fin.
*/
-- Respuesta
Fue aplicado con el procedimiento ACTIVARCITA, donde el paciente tiene que solicitar que activen su cita con el idcita dado cuando
creo su cita.

/*
RB102.	La activación de citas está disponible desde tres horas (3h.) antes de
la hora programada y hasta cinco minutos (5min) después de dicha hora.
*/
-- Respuesta
Fue aplicado en el procedimiento ACTIVARCITA, donde solo se puede activar una cita 3 horas antes y 5 minutos despues de la cita, 
o sino da como error que no se puede activar la cita debido a que se caduco el tiempo de activacion.

/*
RB103.	Los médicos, cuando van a atender a un paciente, tienen acceso a su
historia clínica, únicamente si el paciente ha activado su cita. Para casos
fortuitos o de excepción, el médico tiene que pedir autorización con el
personal designado para ello.
*/
-- Respuesta
Fue aplicado en el procedimiento ACCEDERHISTORIAMED, el cual recibe la cedula del paciente, y los datos de la historia que 
va a insertar el medico, solo se puede acceder a la historia clinica del paciente si el medico tiene una cita, y esta cita tiene
como estadocita=activada, si no, tenemos como salida los posibles errores.

/*
RB104.	La historia médica de un paciente está disponible para que el médico
pueda atender adecuadamente al paciente, registre los eventos que la “Clínica
Universidad Nacional” ha determinado, autorice la entrega de medicamentos y
cuando termina el registro, el médico cierra el acceso. En el caso de que el
médico no haga el cierre, el sistema automáticamente tiene que hacer el cierre
pasadas dos horas (2h.) de terminada su atención.
*/
-- Respuesta
Fue aplicado con el trigger ESTADOCITA, donde si no se modifica la historiaclinica del paciente y estadocita=activada, al pasar
las dos horas estadocita pasa a "finalizada" y no se puede modificar la historiaclinica.

/*
RB105.	Después de cada cita, el médico tiene que hacer el informe oficial
determinado por	 la “Clínica Universidad Nacional”.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB106.	Los medicamentos que formule el médico se tienen que registrar y deben
estar en la lista del POS y se debe tener una alerta en el caso de
medicamentos de alto riesgo. Para casos de excepción, el paciente debe tener
autorización o el médico debe solicitarla a la persona que la “Clínica
Universidad Nacional” haya designado para ello.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos, ademas se especifico que los temas relacionados
con medicamentos no se tienen en cuenta en esta etapa del proyecto.
/*
RB107.	La farmacia/droguería sólo entrega los medicamentos formulados por el
médico, a la persona autorizada y cumpliendo con las demás normas establecidas
por la “Clínica Universidad Nacional”.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos, ademas se especifico que los temas relacionados
con medicamentos no se tienen en cuenta en esta etapa del proyecto.

/*
RB108.	Cuando un paciente no asiste a una cita, tiene que pagar una
penalización. Para casos pre-establecidos, fortuitos o de fuerza mayor, esta
penalización no tiene efecto.
*/
-- Respuesta
No aplica, ya que en esta etapa del proyecto no tuvimos en cuenta temas relacionados con el dinero.

/*
RB109.	Si un paciente no asiste a diez (10) o más citas médicas, sin
presentar excusas aceptadas, en periodos de seis (6) meses, se le aplica una
sanción adicional en dinero en el monto que especifique la “Clínica
Universidad Nacional”; esto se le comunica a la Entidad de Salud y en caso de
reincidencia, puede aplicar la suspensión del servicio de citas médicas a ese
paciente.
*/
-- Respuesta
No aplica, ya que en esta etapa del proyecto no tuvimos en cuenta temas relacionados con el dinero.

/*
RB110.	Si un médico no puede atender a sus pacientes en un determinado
momento, tiene que ser reemplazado por otro médico, o llegar a un acuerdo con
el paciente para hacer una nueva programación.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB111.	Si el consultorio asignado para una cita médica presenta alguna
deficiencia, mal estado o hay inconvenientes para su utilización. Se le tiene
que avisar al médico y con el paciente se acuerda el procedimiento a seguir.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB112.	Los consultorios deben encontrarse en un estado excelente. Tienen que
estar listos y exentos de cualquier tipo de actividad o elemento comercial.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB113.	Si el médico considera que el consultorio asignado para atender a un
paciente presenta algún deterioro o problema hasta el punto que él considera
impracticable la cita médica, de inmediato se tiene que comunicar con las
personas de asignación de citas para informar este evento y con el paciente,
acordar el procedimiento a seguir.
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos.

/*
RB114.	Para aseo, mantenimiento programado y otras actividades que se tengan
que realizar a un consultorio, se tienen que programar una o más sesiones de
veinte minutos (20 min.).
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos, ademas se especifico que temas relacionados
con aseo y mantenimiento no se tienen en cuenta en esta etapa del proyecto.

/*
RB115.	A un consultorio se le tiene que programar como mínimo una sesión 
para aseo al día
*/
-- Respuesta
No aplica ya que esto es una aplicacion por fuera del entorno de las bases de datos, ademas se especifico que temas relacionados
con aseo y mantenimiento no se tienen en cuenta en esta etapa del proyecto.

/*
RB116.	En este momento las especialidades que atiende la “Clínica Universidad
Nacional” son: medicina general, ginecología, nutrición y dietética,
odontología, optometría, oftalmología, pediatría, psicología, terapia
ocupacional, gastroenterología, traumatología y ortopedia, neumología,
cardiología, dermatología, urología, otorrinolaringología, endocrinología;
pero en poco tiempo la clínica tiene un plan de ampliar a muchas más
especialidades.
*/
-- Respuesta
Fue aplicado, en la tabla especialidades solo se ingresan estas especialidades y ninguna mas.
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP01','Medicina General');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP02','Ginecologia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP03','Nutricion y Dietetica');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP04','Odontologia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP05','Optometria');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP06','Oftalmologia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP07','Pediatria');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP08','Psicologia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP09','Terapia Ocupacional');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP10','Gastroentrologia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP11','Traumatologia y Ortopedia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP12','Neumologia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP13','Cardiologia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP14','Dermatologia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP15','Urologia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP16','Otorrinolaringologia');
INSERT INTO jumunozle.VISTA_ESPECIALIDAD VALUES('ESP17','Endocrinologia');

/*
RB117.	Cuando un paciente deja de ser atendido por la “Clínica Universidad
Nacional”, toda su información queda almacenada y disponible, total o
parcialmente, para cuando se necesite o sea requerida por las personas o 
entidades, previamente autorizadas, o que así esté establecido en las normas 
sanitarias internacionales, nacionales, legales y/o jurídicas.
*/
-- Respuesta
Fue aplicado, cuando un paciente deja de ser atendido en la clinica, todos sus datos quedan almacenados en la base de datos e
inactivopac=1, mediante esto se tiene una vista para ver todos los pacientes inactivos.
/*
RB118.	Se requiere información de los médicos (en diferentes presentaciones).
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_MEDICOS, donde se tiene toda la informacion de los medicos registrados en la clinica.

/*
RB119.	Información de pacientes (en diferentes presentaciones).
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_PACIENTE, donde se tiene toda la informacion de los pacientes registrados en la clinica.

/*
RB120.	Información de cotizantes (en diferentes presentaciones).
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_COTIZANTES, donde se tiene toda la informacion de los cotizantes registrados en la clinica.

/*
RB121.	Información de beneficiarios (en diferentes presentaciones).
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_BENEFICIARIOS, donde se tiene toda la informacion de los beneficiarios registrados en la clinica.

/*
RB122.	Información sobre los consultorios (en diferentes presentaciones).
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_CONSULTORIO, donde se tiene toda la informacion de los consultorios registrados en la clinica.

/*
RB123.	Información sobre las citas (en diferentes presentaciones).
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_CITA, donde se tiene toda la informacion de todas las citas registradas en la clinica.

/*
RB124.	Información sobre la ocupación de habitaciones (en diferentes 
presentaciones).
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_HABOCUPADAS y VISTA_HABDISPONIBLES, donde se tiene toda la informacion de las habitaciones ocupadas y disponibles en la clinica.

/*
RB125.	Información sobre la ocupación de camas (en diferentes 
presentaciones).
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_CAMASDISPONIBLES y VISTA_CAMASOCUPADAS, donde se tiene toda la informacion de las camas disponibles y ocupadas en la clinica.

/*
RB126.	Información sobre la ocupación de UCIs (en diferentes presentaciones).
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_UCIDISPONIBLES y VISTA_UCIOCUPADAS, donde se tiene toda la informacion de las UCIs disponibles y ocupadas en la clinica.

/*
RB127.	Información sobre especialidades atendidas en la “Clínica Universidad 
Nacional”.
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_ESPECIALIDAD, donde se tiene toda la informacion de todas las especialidades que se atienden en la clinica.

/*
RB128.	Información de los pacientes hospitalizados.
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_PACIENTESHOSPITALIZADOS, donde se tiene toda la informacion de todos los pacientes que estan en una cama/habitacion/uci.

/*
RB129.	Pacientes dados de alta en un determinado día.
*/
-- Respuesta
No fue aplicado, ya que no trabajamos en dar de alta los pacientes de la clinica.

/*
RB130.	Información sobre categorías que se manejan en la “Clínica 
Universidad Nacional”.
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_CATEGORIAS, donde se tiene toda la informacion de todas las categorias registradas en la clinica.

/*
RB131.	Información de pacientes que cancelan cita para una determinada fecha 
y hora.
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_CITASCANCELADAS, donde se tiene toda la informacion de todas las citas canceladas en la clinica, donde se guarda la hora que fue cancelada la cita.

/*
RB132.	Información de la lista de condiciones para asignar una 
habitación/cama a un paciente.
*/
-- Respuesta
No fue aplicado, ya que no tomamos en cuenta las condiciones para asignar una habitacion/cama a los pacientes.

/*
RB133.	Información de listas de espera del día.
*/
-- Respuesta
No fue aplicado, ya que no aplicamos listas de esperas en el proyecto.

/*
RB134.	Información de listas de espera para citas médicas.
*/
-- Respuesta
No fue aplicado, ya que no aplicamos listas de esperas en el proyecto.

/*
RB135.	Información de listas de espera para hospitalización.
*/
-- Respuesta
No fue aplicado, ya que no aplicamos listas de esperas en el proyecto.

/*
RB136.	Información de las listas de casos de fuerza mayor.
*/
-- Respuesta
Lo consideramos como no aplica ya que no tuvimos en cuenta los casos de fuerza mayor en este sistema.

/*
RB137.	Médicos que han incumplido diez (10) o más citas médicas en un 
semestre.
*/
-- Respuesta
No fue aplicado, ya que no tuvimos en cuenta el incumplimiento de citas en el proyecto.

/*
RB138.	Valores en pesos por sanción de inasistencia de pacientes a citas 
médicas.
*/
-- Respuesta
No aplica, ya que en esta etapa del proyecto no tuvimos en cuenta temas relacionados con el dinero.

/*
RB139.	Paciente(s) que ha(n) solicitado alta voluntaria en contra del 
consejo del (de los) médico(s).
*/
-- Respuesta

No fue aplicado, ya que no tuvimos en cuenta las dadas de alta a los pacientes y tampoco la solicitud de alta voluntaria.
/*
RB140.	Paciente(s) sancionado(s) por incumplimiento de citas médicas.
*/
-- Respuesta
No aplica, ya que en esta etapa del proyecto no tuvimos en cuenta temas relacionados con el dinero.

/*
RB141.	Paciente(s) sancionado(s) que en el semestre han incumplido diez (10) 
o más citas médicas.
*/
-- Respuesta
No aplica, ya que en esta etapa del proyecto no tuvimos en cuenta temas relacionados con el dinero.

/*
RB142.	Camas disponibles para hospitalización.
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_CAMASDISPONIBLES, donde se tiene toda la informacion de todas las camas disponibles en el momento en la clinica.

/*
RB143.	Habitaciones, camas disponibles para hospitalización.
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_CAMASDISPONIBLES y VISTA_HABDISPONIBLES, donde se tiene toda la informacion de las camas y habitaciones disponibles en la clinica.

/*
RB144.	UCIs disponibles para hospitalización
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_UCIDISPONIBLES, donde se tiene toda la informacion de todas las UCIs disponibles en el momento en la clinica.

/*
RB145.	Número de camas ocupadas en un día, en una semana, en un mes, en un 
semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB146.	Número de habitaciones ocupadas en un día, en una semana, en un mes, 
en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB147.	Número de UCIs ocupadas en un día, en una semana, en un mes, en un 
semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB148.	Número de camas disponibles en un día, en una semana, en un mes, en 
un semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB149.	Número de habitaciones disponibles en un día, en una semana, en un 
mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB150.	Número de UCIs disponibles en un día, en una semana, en un mes, en un 
semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB151.	Número de pacientes dados de alta en un día.
*/
-- Respuesta
No fue aplicado, ya que no tuvimos en cuenta las dadas de alta a los pacientes y tampoco la solicitud de alta voluntaria.

/*
RB152.	Número de paciente(s) que ha(n) solicitado alta voluntaria en contra 
del consejo del (de los) médico(s) en un día, en una semana, en un mes, en un 
semestre, en un año.
*/
-- Respuesta
No fue aplicado, ya que no tuvimos en cuenta las dadas de alta a los pacientes y tampoco la solicitud de alta voluntaria.

/*
RB153.	Número de días que un paciente estuvo en una cama.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB154.	Número de días que un paciente estuvo en una habitación.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB155.	Número de días que un paciente estuvo en una UCI.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB156.	Número de días que un paciente estuvo hospitalizado.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB157.	Número máximo de días presentado en la “Clínica Universidad Nacional” 
de duración de un paciente hospitalizado (contados a partir del día en que se 
hospitalizó hasta el día que se dio de alta, independiente de cambios de 
cama, cambios a UCI, cambios de habitación).
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB158.	Número de citas médicas programadas en un día, en una semana, en un 
mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB159.	Número de pacientes atendidos por un médico(s) en un día, en una 
semana, en un mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB160.	Número de citas incumplidas por el (los) paciente(s) en un día, en 
una semana, en un mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, ya que no tuvimos en cuenta el incumplimiento de citas en el proyecto.

/*
RB161.	Número de citas incumplidas por el (los) cotizante(s) en un día, en 
una semana, en un mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, ya que no tuvimos en cuenta el incumplimiento de citas en el proyecto.

/*
RB162.	Número de citas incumplidas por el (los) beneficiario(s) en un día, 
en una semana, en un mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, ya que no tuvimos en cuenta el incumplimiento de citas en el proyecto.

/*
RB163.	Número de citas canceladas por el (los) paciente(s) en un día, en una 
semana, en un mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB164.	Número de citas canceladas por el (los) cotizante(s) en un día, en 
una semana, en un mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB165.	Número de citas canceladas por el (los) beneficiario(s) en un día, en 
una semana, en un mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB166.	Número de citas incumplidas por el (los) médico(s) en un día, en una 
semana, en un mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, ya que no tuvimos en cuenta el incumplimiento de citas en el proyecto.

/*
RB167.	Número de citas canceladas por el (los) médico(s) en un día, en una 
semana, en un mes, en un semestre, en un año.
*/
-- Respuesta
No fue aplicado, no encontramos la forma de aplicar este requerimiento en la base de datos.

/*
RB168.	Número de médicos que han incumplido diez (10) o más citas médicas en 
un semestre.
*/
-- Respuesta
No fue aplicado, ya que no tuvimos en cuenta el incumplimiento de citas en el proyecto.

/*
RB169.	Número de consultorios disponibles, organizados por especialidad.
*/
-- Respuesta
Fue aplicado, mediante la vista VISTA_CONSULTORIOS, donde se tiene toda la informacion de todos los consultorios disponibles, organizados por especialidad.

/*
RB170.	Número de casos de fuerza mayor en un día, en una semana, en un mes, 
en un semestre, en un año, organizados por tipo de fuerza mayor.
*/
-- Respuesta
Lo consideramos como no aplica ya que no tuvimos en cuenta los casos de fuerza mayor en este sistema.

/*
RB171.	Presentaciones propuestas por cada grupo, no consideradas en los 
casos anteriores.
*/
-- Respuesta
No aplica, debido a que no tuvimos presentaciones propuestas.

/*
RT1.	La solución al problema se va a trabajar utilizando un sistema de 
bases de datos relacional.
*/
-- Respuesta
Fue aplicado, la solucion al problema se trabajo en tres bases de datos relacionales: Sybase, Microsoft SQL, y Oracle.

/*
RT2.	Como metodología se va a utilizar la simplificación del problema en 
un modelo conceptual, luego en un modelo lógico, luego en un modelo físico, 
terminando con la implementación en los servidores de bases de datos.
*/
-- Respuesta
Fue aplicado, el problema fue solucionado mediante el uso de la herramienta powerdesigner, la cual nos ayudo en la creacion de los
modelos, que luego nos dieron la creacion de los escenarios.

/*
RT3.	Las entidades y relaciones que se ven del mundo real, van a ser 
implementadas en una base de datos relacional, utilizando objetos como 
tablas, vistas, índices y otras facilidades que brindan las bases de datos 
relacionales, tales como funciones, procedimientos almacenados, triggers, 
cursores y bitácoras, entre otras.
*/
-- Respuesta
Fue aplicado, se usaron casi todos los objetos dados para facilitar el uso de las bases, como triggers, indices, procedimientos,
vistas,etc

/*
RT4.	Cada objeto de base de datos que se cree, va a tener un nombre único, 
para identificarlo.
*/
-- Respuesta
Fue aplicado, cada tabla, vista, trigger, tiene un nombre unico.

/*
RT5.	Las columnas de cada tabla definida, tienen que ser atributos de la 
entidad que se está definiendo y se pueden definir tantas columnas como sean 
necesarias, limitadas únicamente en número, por restricciones de la base de 
datos que se esté utilizando.
*/
-- Respuesta
Fue aplicado, cada tabla tiene atributos y cada una tiene los atributos que se consideraron necesarios.

/*
RT6.	La(s) columna(s) que tengan la propiedad de ser identificadoras, 
tienen que ser definidas con las características de obligatorias y con valor 
único.
*/
-- Respuesta
Fue aplicado, cada columna identificadora fue definida como obligatoria y tienen valor unico.

/*
RT7.	En los casos de identificadores compuestos, ninguno de sus atributos 
o conjunto de atributos, puede ser también un identificador (esto para 
aplicar el concepto de minimalidad).
*/
-- Respuesta
Fue aplicado, ningun atributo fue utilizado como identificador a la vez.

/*
RT8.	Cada tabla definida tiene que tener una llave primaria, la cual puede 
ser simple o compuesta.
*/
-- Respuesta
Fue aplicado, cada tabla tiene una llave primaria la cual es obligatoria y unica.

/*
RT9.	Al definir una tabla, no se deben permitir grupos repetitivos.
*/
-- Respuesta
Fue aplicado, cada tabla no permite grupos repetitivos, como por ejemplo la duplicacion de llaves principales.

/*
RT10.	Las reglas simples y/o sencillas deben definirse como restricciones.
*/
-- Respuesta
Fue aplicado, en cada tabla existen reglas definidas como restricciones.

/*
RT11.	Las reglas complejas tienen que definirse utilizando programación y 
haciendo uso, por ejemplo, de funciones, procedimientos almacenados, triggers 
y/o cursores.
*/
-- Respuesta
Fue aplicado, se usaron triggers, funciones, y procedimientos para definir reglas complejas.

/*
RT12.	Para controlar la integridad de la información entre tablas, se 
tienen que definir las llaves foráneas que se consideren necesarias, las 
cuales pueden ser simples o compuestas.
*/
-- Respuesta
Fue aplicado, se usaron llaves foraneas e indices para las relaciones entre las tablas, las cuales solo fueron simples.

/*
RT13.	Todas las consultas a la base de datos que se implementen como 
consultas rutinarias y/o típicas tienen que definirse a través del mecanismo 
de vistas y/o programación.
*/
-- Respuesta
Fue aplicado, solo se pueden insertar/consultar/modificar datos atraves de vistas y procedimientos.

/*
RT14.	Se tienen que definir índices, tantos como se consideren necesarios.
*/
-- Respuesta
Fue aplicado, en casi todas las tablas del proyecto tenemos un indice.

/*
RT15.	El sistema tiene que tener un registro de las Entidades de Salud.
*/
-- Respuesta
Fue aplicado, este registro se ve mediante la vista VISTA_ENTIDADESSALUD

/*
RT16.	El sistema tiene que tener un registro de los pacientes (cotizantes y 
beneficiarios).
*/
-- Respuesta
Fue aplicado, este registro se ve mediante la vista VISTA_PACIENTE

/*
RT17.	El sistema tiene que tener un registro de los médicos.
*/
-- Respuesta
Fue aplicado, este registro se ve mediante la vista VISTA_MEDICOS

/*
RT18.	El sistema tiene que tener un registro de las camas para pacientes 
hospitalizados en la “Clínica Universidad Nacional”.
*/
-- Respuesta
Fue aplicado, este registro se ve mediante la vista VISTA_CAMA

/*
RT19.	El sistema tiene que tener un registro de las habitaciones para 
pacientes hospitalizados en la “Clínica Universidad Nacional”.
*/
-- Respuesta
Fue aplicado, este registro se ve mediante la vista VISTA_HABITACION

/*
RT20.	El sistema tiene que tener un registro de las Unidades de cuidados 
intensivos,	UCIs, en la “Clínica Universidad Nacional”.
*/
-- Respuesta
Fue aplicado, este registro se ve mediante la vista VISTA_UCI

/*
RT21.	El sistema tiene que tener un registro de los consultorios en la 
“Clínica Universidad Nacional”.
*/
-- Respuesta
Fue aplicado, este registro se ve mediante la vista VISTA_CONSULTORIO

/*
RT22.	El sistema tiene que tener un registro de las políticas de 
asignación/cancelación de citas.
*/
-- Respuesta
Fue aplicado, este registro se ve mediante la vistas VISTA_POLITICASCITAS

/*
RT23.	El sistema tiene que tener un registro que contenga los pacientes que 
tiene que atender.
*/
-- Respuesta
Fue aplicado, este registro se ve mediante la vista VISTA_PACIENTESPORATENDER

/*
RT24.	El sistema tiene que tener un registro que contenga la información de 
los pacientes que ya no atiende.
*/
-- Respuesta
Fue aplicado, este registro se ve mediante la vista VISTA_PACIENTESINACTIVOS

/*
RT25.	El sistema tiene que controlar que los pacientes efectivamente estén 
registrados en una Entidad de Salud ya sea como cotizante o beneficiario.
*/
-- Respuesta
Fue aplicado, mediante el procedimiento INSERTARPACIENTE, en el cual si no se ingresa una entidad en la cual este registrado el 
paciente, da como error que el paciente tiene que estar registrado en una entidad de salud.

/*
RT26.	El sistema tiene que controlar que sólo se asignan profesionales 
contratados por la “Clínica Universidad Nacional”.
*/
-- Respuesta
Fue aplicado, el procedimiento CREARCITA solo asigna profesionales que estan registrados en el sistema.

/*
RT27.	El sistema tiene que controlar que sólo se asignan los consultorios 
disponibles en la “Clínica Universidad Nacional”.
*/
-- Respuesta
Fue aplicado, el procedimiento CREARCITA solo asigna consultorios disponibles en la Clinica.

/*
RT28.	El sistema tiene que controlar que sólo se asignan las habitaciones 
disponibles en la “Clínica Universidad Nacional”.
*/
-- Respuesta
Fue aplicado, el procedimiento ASIGNARHABITACION solo asigna habitaciones disponibles en la clinica.

/*
RT29.	El sistema tiene que controlar que sólo se asignan las UCIs 
disponibles en la “Clínica Universidad Nacional”.
*/
-- Respuesta
Fue aplicado, el procedimiento ASIGNARUCI solo asigna UCIs disponibles en la clinica.

/*
RT30.	El sistema tiene que controlar que cada cita médica, sólo y 
únicamente, se asigna a un profesional, un paciente, en un consultorio 
apropiado, en una determinada fecha y hora.
*/
-- Respuesta
Fue aplicado, el procedimiento CREARCITA solo asigna un profesional, un paciente, en un consultorio disponible y en una fecha y hora
en la cual el profesional este disponible.
/*
RT31.	El sistema tiene que tener un registro histórico en donde se puedan 
encontrar las diferentes operaciones hechas en las bases de datos, 
relacionadas con sus contenidos, tales como adiciones, actualizaciones y 
borrados.
*/
-- Respuesta
Fue aplicado, existe la tabla bitacora donde, mediante triggers, se registran todos los cambios y operaciones hechos en la base de datos.
/*
RT32.	El registro histórico tiene que tener información, por lo menos, 
sobre la identificación de quien hizo la operación, desde dónde se efectuó la 
acción, los objetos de bases de datos afectados, el tipo de acción, la fecha, 
hora y demás información que se considere importante y/o necesaria.
*/
-- Respuesta
Fue aplicado, la bitacora registra la identificacion de quien hizo el cambio, desde donde, los objetos afectados, el tipo de accion y la fecha y hora del cambio.

/*
RT33.	El sistema tiene que tener un mecanismo donde se puedan observar las 
acciones indeseadas que se lleven a cabo sobre el registro histórico 
(bitácoras) e incluir todos los datos que se consideren necesarios, sin 
faltar la identificación de quien hizo la operación, el tipo de operación 
indeseada, desde dónde se hizo, fecha y hora.
*/
-- Respuesta
Fue aplicado, en la tabla accionesIndeseadasBitacora se registran todos los cambios indeseados si algun usuario diferente de "jumunozle","jhprieto","nicortesg" hace un cambio en la base de datos.

/*
RT34.	Para la consulta, el ingreso y/o modificación de la información 
contenida en las bases de datos, únicamente se van a utilizar vistas y/o 
programación (funciones procedimientos almacenados, triggers, cursores) que 
indican las personas, grupos y/o procesos autorizados para hacerlo y nunca 
operando en forma directa sobre las tablas de las bases de datos.
*/
-- Respuesta
Fue aplicado, para todos estos casos se usan vistas, funciones, procedimientos, para los cuales solo estan autorizados algunos usuarios.

/*
RT35.	El sistema tiene que garantizar que si varias personas trabajando en 
forma concurrente llegan a modificar un mismo dato de manera simultánea, la 
operación siempre se realiza de forma controlada y sincronizada.
*/
-- Respuesta
No fue aplicado, no aplicamos la transacciones necesarias para cumplir con este requisito.
/*
RT36.	El sistema tiene que permitir el ingreso de datos en lotes, ya sea a 
través de sentencias sql o provenientes de hojas de Excel y/o en forma 
combinada.
*/
-- Respuesta
Esta parcialmente implementado ya que no probamos el ingreso de datos provenientes de hojas de excel.

/*
RI1.	La implementación va ser progresiva, a través del tiempo, de acuerdo 
a los temas vistos en las sesiones de clase.
*/
-- Respuesta
Fue aplicado, todo fue implementado de acuerdo a los temas vistos.

/*
RI2.	La implementación tiene que tener en cuentas los requerimientos 
básicos de los usuarios (requerimientos RB) y los requerimientos técnicos 
(requerimientos RT).
*/
-- Respuesta
Fue aplicado, se tuvieron en cuenta la mayoria de los requerimientos necesarios.

/*
RI3.	Cada tabla debe tener una llave primaria (PK).
*/
-- Respuesta
Fue aplicado, cada tabla tiene una llave primaria.

/*
RI4.	Las llaves primarias (PK) pueden ser simples o compuestas.
*/
-- Respuesta
Fue aplicado, todas las tablas tienen solo llaves simples.

/*
RI5.	Las tablas pueden tener una o ninguna o varias llaves foráneas (FK).
*/
-- Respuesta
Fue aplicado, la mayoria de tablas tienen llaves foraneas.

/*
RI6.	Las llaves foráneas (FK) pueden ser simples o compuestas.
*/
-- Respuesta
Fue aplicado, todas las llaves foraneas fueron simples.

/*
RI7.	Las tablas pueden tener asociadas una o varias o ninguna vista.
*/
-- Respuesta
Fue aplicado, todas las tablas tienen asociada al menos una vista.

/*
RI8.	Las tablas pueden tener uno o ninguno o varios índices.
*/
-- Respuesta
Fue aplicada, la mayoria de tablas tienen un indice.

/*
RI9.	Las tablas pueden tener tantas columnas como se requieran, pero cada 
columna debe ser una característica de la tabla definida.
*/
-- Respuesta
Fue aplicada, todas las tablas tienen tantas columnas como se requirieron y cada columna es una caracteristica de la tabla.

/*
RI10.	Las vistas pueden ser sobre una o varias tablas y/o vistas.
*/
-- Respuesta
Fue aplicada, las vistas fueron de una tabla y algunas de varias.

/*
RI11.	Las columnas de una tabla que sean identificadoras tienen que tener 
las características de obligatorias y con valor único.
*/
-- Respuesta
Fue aplicada, las columnas identificadas son obligatorias y de valor unico.

/*
RI12.	Las reglas sencillas siempre se tienen que definir a nivel de tabla, 
columna o celda como restricciones (constraints).
*/
-- Respuesta
Fue aplicada, la reglas sencillas de cada tablas estan definidas como restraints.

/*
RI13.	Las reglas de integridad entre tablas se tienen que definir con 
llaves foráneas (FK).
*/
-- Respuesta
Fue aplicada, se definieron en casi todas las tablas llaves foraneas.

/*
RI14.	Las reglas complejas se deben definir utilizando programación 
(funciones, procedimientos almacenados, triggers y/o cursores).
*/
-- Respuesta
Fue aplicada, se usaron funciones, procedimiento y triggers.

/*
RI15.	Para llevar un control sobre la información de los médicos, 
pacientes, consultorios y habitaciones, se debe tener una bitácora para 
seguimiento, lo más detallada posible, que incluya, persona que hizo la 
operación, las tablas afectadas, la identificación desde donde se realizó la 
operación, el tipo de operación (inserción / actualización / borrado), la 
fecha y hora.
*/
-- Respuesta
Fue aplicada, en la tabla bitacora se registran todos los cambios hechos en la base de datos, y la informacion de quien hizo el cambio.

/*
RI16.	Para registrar las posibles acciones indebidas sobre la(s) 
bitácora(s), llevar un control donde se registren las operaciones de 
actualización/borrado sobre la(s) bitácora(s), donde se incluya persona que 
hizo la operación, la identificación desde donde se realizó la operación, el 
tipo de operación (actualización/borrado), la fecha y hora.
*/
-- Respuesta
Fue aplicada, en la tabla accionesindeseadasbitacora se registra todos los cambios indeseados a la tabla bitacora si los usuarios que hicieron el cambio
no son "jumunozle","jhprieto","nicortesg"
/*
RI17.	Llevar el control de médicos.
*/
-- Respuesta
Fue aplicada, se tiene el control de los medicos mediante la vista VISTA_MEDICOS

/*
RI18.	Llevar control de pacientes.
*/
-- Respuesta
Fue aplicada, se tiene el control de los pacientes mediante la vista VISTA_PACIENTE

/*
RI19.	Llevar el control de consultorios.
*/
-- Respuesta
Fue aplicada, se tiene el control de los consultorios mediante la vista VISTA_CONSULTORIO

/*
RI20.	Llevar el control de asignación de citas.
*/
-- Respuesta
Fue aplicada, se tiene el control de las citas mediante la vista VISTA_CITA
/*
RI21.	Llevar el control de habitaciones.
*/
-- Respuesta
Fue aplicada, se tiene el control de las habitaciones mediante la vista VISTA_HABITACION

/*
RI22.	Llevar el control de camas.
*/
-- Respuesta
Fue aplicada, se tiene el control de las camas mediante la vista VISTA_CAMA

/*
RI23.	Llevar el control de UCIs.
*/
-- Respuesta
Fue aplicada, se tiene el control de las UCIS mediante la vista VISTA_UCI

/*
RI24.	Los datos se pueden suministrar utilizando comandos SQL o 
provenientes de hojas de Excel y/o en forma combinada.
*/
-- Respuesta
Fue parcialmente aplicado, solo se pueden suministrar datos utilizando comandos SQL, no probamos mediante Excel.

/*
RI25.	Tener siempre conjuntos de datos válidos para poblar el sistema, 
durante la elaboración de pruebas de calidad.
*/
-- Respuesta
Fue aplicado, se tienen listos datos para poblar las bases de datos.

/*
RI26.	Tener siempre datos disponibles para comprobar que las reglas se 
cumplen, durante la elaboración de pruebas de calidad.
*/
-- Respuesta
No fue aplicado, AUN no se tienen scripts en esta version del avance para comprobar las reglas.

/*
RI27.	Para las pruebas de calidad, deben contar con datos típicos: datos de 
los médicos, datos de pacientes, datos de consultorios, datos de las 
habitaciones, datos de las camas para hospitalizados, datos de UCIs, datos de 
citas, datos de asignación de habitaciones/camas/UCIs/citas, y en general, 
datos de interés que considere el grupo necesarios para la 
solución/implementación/prueba del problema/solución.
*/
-- Respuesta
Fue aplicado, se tienen listos datos para poner un escenario de ejemplo.

/*
RI28.	Implementación en el servidor Adaptive Server Enterprise SAP, 
utilizando los servidores dispuestos para el curso, con las cuentas asignadas 
en la U.N.
*/
-- Respuesta
Fue aplicado, la solucion en ASE, usando los servidores para el curso, y las cuentas de la U.N

/*
RI29.	Implementación en el servidor Microsoft SQL Server, utilizando los 
servidores dispuestos para el curso con las cuentas asignadas en la U.N.
*/
-- Respuesta
Fue aplicado, la solucion en Microsoft SQL, usando los servidores para el curso, y las cuentas de la U.N

/*
RI30.	Implementación en el servidor Oracle, utilizando los servidores 
dispuestos para el curso, con las cuentas asignadas en la U.N.
*/
-- Respuesta
Fue aplicado, la solucion en ORACLE, usando los servidores para el curso, y las cuentas de la U.N

/*
RI31.	En cada sustentación se tiene que indicar de forma explícita los 
requerimientos incluidos y no incluidos en la implementación.
*/
-- Respuesta
Fue aplicado, en la lista de control se indican los requerimientos incluidos y en este archivo se responden a los requerimientos.

/*
RI32.	Al iniciar una sesión de sustentación, toda la información 
relacionada con modelos e información, tienen que retirarse de los servidores 
de bases de datos, es decir, todas las bases de datos tienen que estar sin 
objetos definidos por los usuarios.
*/
-- Respuesta
Fue aplicado, cada miembro del grupo no tiene objetos definidos en las bases de datos.

/*
RI33.	La implementación del escenario básico de trabajo, siempre debe 
realizarse a través de scripts listos para ser ejecutados en modalidad batch. 
El escenario básico son las tablas, restricciones, vistas, funciones, 
procedimientos almacenados, triggers, cursores, permisos y otras facilidades 
definidas por los usuarios, y sin datos.
*/
-- Respuesta
Fue aplicado, se tienen los archivos para la creacion de los escenarios en cada servidor.

/*
RI34.	Los datos válidos para poblar las tablas tienen que estar listos, ya 
sea como sentencias sql o datos que vienen de hojas en Excel y/o datos que 
vienen de forma combinada.
*/
-- Respuesta
Fue parcialmente aplicado, los datos vienen en sentencias SQL, ya que no probamos en Excel.

/*
RI35.	Se tiene que disponer de scripts para cargar datos que muestren un 
cierto estado del sistema en un momento bien determinado, para luego hacer 
pruebas de funcionabilidad. Esto con el objeto de ver, durante la 
sustentación, que el sistema opera de acuerdo con lo esperado.
*/
-- Respuesta
No fue aplicado, en esta version del avance AUN no se tienen scripts para mostrar un momento bien determinado

/*
RI36.	Se tiene que disponer de scripts para cargar datos que muestren el 
sistema en un momento donde absolutamente todo está ocupado, es decir, que en 
ese estado no hay posibilidad de hacer asignaciones por estar totalmente 
copado el sistema. Esto con el objeto de ver, durante la sustentación,  que 
el sistema opera de acuerdo con lo esperado.
*/
-- Respuesta
No fue aplicado, en esta version del avance AUN no se tienen scripts para mostrar un momento en el que todo este ocupado

/*
RI37.	Siempre se tienen que tener disponibles datos para comprobar que se 
cumplen las reglas definidas. Esto significa, tener datos que sirven y otros 
que el sistema rechaza o procesa de acuerdo con las reglas, y de esta manera, 
durante la sustentación, corroborar que las reglas y requerimientos se 
cumplieron.
*/
-- Respuesta
No fue aplicado, en esta version del avance AUN no se tienen scripts para comprobar las reglas definidas.

/*
RI38.	Los registros históricos, de operaciones sobre las bases de datos, 
deben trabajarse utilizando el concepto de bitácoras.
*/
-- Respuesta
Fue aplicado, se trabajaron los registros historicos con el concepto bitacora en bases de datos.
RI39.	Consultas a los registros históricos del sistema (bitácoras).
*/
-- Respuesta
Fue aplicado, las consultas se hacen mediante la vista VISTA_BITACORA

/*
RI40.	Consultas al sistema de control de los registros históricos del 
sistema (control de operaciones no deseadas sobre las bitácoras).
*/
-- Respuesta
Fue aplicado, las consultas se hacen mediante la vista VISTA_ACCIONESINDESEADASBITACORA

/*
RI41.	Como herramientas cliente, se pueden usar las herramientas que se 
conecten a los servidores de bases de datos de la U.N., sin importar el 
proveedor de la herramienta o la versión, siempre y cuando operen 
adecuadamente.
*/
-- Respuesta
Fue aplicado, todos los miembros estan listos por si se llega a necesitar este requerimiento.

/*
Requerimientos adicionales.
*/
-- Respuesta
No aplicados.

/*
Caso(s) en que muchos usuarios en forma concurrente pueden querer afectar en 
forma simultáneamente un mismo dato.
*/
-- Respuesta
Insertar pacientes, crear citas, cancelar citas, asignar habitaciones, asignar ucis,
