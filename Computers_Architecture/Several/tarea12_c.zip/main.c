#include <stdio.h>
#include <stdint.h>

int32_t x[3] = {257684, -293205, 62870};
int32_t *p;
int32_t min;
int8_t i = 0;

int main()
{
    // TODO: inicializar el puntero p
    p = x;

    // TODO: asumir que el primer elemento es el menor
    min = p[0];

    // TODO: recorrer el arreglo y comparar cada elemento
    while (i < 3)
    {
        if (p[i] < min)
        {
            min = p[i];
        }
        i++;
    }

    // TODO: imprimir el valor mínimo
    printf("min = %d\n", min);

    return 0;
}
