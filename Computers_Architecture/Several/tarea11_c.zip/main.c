#include <stdio.h>
#include <stdint.h>

int32_t x[3] = {257684, -293205, 62870};
int32_t *p;
int32_t max;
int8_t i = 0;

int main()
{
    // TODO: inicializar puntero p con la dirección del arreglo x
    p = x;

    // TODO: asumir que el primer elemento es el mayor
    max = p[0];

    // TODO: recorrer el arreglo para encontrar el valor máximo
    while (i < 3)
    {
        // si encontramos un elemento mayor que max, lo actualizamos
        if (p[i] > max)
        {
            max = p[i];
        }
        i++;
    }

    // TODO: imprimir el valor máximo
    printf("max = %d\n", max);

    return 0;
}
